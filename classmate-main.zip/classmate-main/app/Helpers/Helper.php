<?php

namespace App\Helpers;
use Illuminate\Support\Facades\DB;

class Helper {

   public function __construct() {}
   
}