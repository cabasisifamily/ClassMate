<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use App\Models\Professor;
use App\Models\User;
use App\Models\Section;
use App\Models\Course;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return redirect()->route('admin.login');
    }

    public function login()
    {
        return redirect()->route('login');
    }

    public function professors()
    {
        return view('admins.professors');
    }

    public function students()
    {
        return view('admins.students');
    }

    public function users()
    {
        return view('admins.users');
    }

    public function account() {
        return view('admins.account');
    }

    public function parents() {
        return view('admins.parents');
    }

    public function dashboard(Request $request)
    {
        if($request->session()->get('user')['pword_reset'] == 1 ) {
            return redirect()->route('admin.changepw');
        }

        $students = Student::all()->count();
        $professors = Professor::all()->count();
        $sections = Section::all()->count();
        $courses = Course::all()->count();

        return view('admins.dashboard',['data' => [
            'students' => $students,
            'professors' => $professors,
            'sections' => $sections,
            'courses' => $courses,
        ]]);
    }

    public function changepw() {
        return  view('admins.changepw');
    }

    public function storeChange(Request $request) {

        $user = User::find($request->session()->get('user')['id']);

        if(!Hash::check($request->current_password,$user->pword)) {
            return redirect()->back()->with('fail','Your current password is incorrect.');
        }

        $validated = $request->validate([
            'password' => ['required', 'max:50','min:8','confirmed'],
            'password_confirmation' => ['required'],
        ]);

        $user->pword = Hash::make($request->password);
        $user->pword_reset = 0;
        $user->update();

        $request->session()->forget('user');
        $request->session()->flush();
        return redirect()->route('login')->with('success','Your have successfully changed your password. Please login your account');

        return $request;
    }

    public function utilities() {
        return view('admins.utilities');
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
