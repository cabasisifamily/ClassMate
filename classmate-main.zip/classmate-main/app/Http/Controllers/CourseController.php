<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $courses = Course::join('course_status','courses.course_status_id','=','course_status.id')
            ->get(['courses.*','course_status.description as status']);
        
        return view('admins.courses.list',['subjects'=>$courses]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("admins.courses.create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $model = new Course;

        $validated = $request->validate([
            'description' => ['required','max:100','min:2','regex:/^[a-zA-Z0-9\s]+$/'],
            'course_status_id' => ['required'],
        ]);

        $model->description = $request->description;
        $model->course_status_id = $request->course_status_id;
        $model->save();

        return redirect("/admin/courses/list")->withSuccess('Record has been successfully saved');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $course = Course::find($id);
        return view("admins.courses.edit",['course' => $course]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $model = Course::find($id);

        $validated = $request->validate([
            'description' => ['required','max:100','min:2','regex:/^[a-zA-Z0-9\s]+$/'],
            'course_status_id' => ['required'],
        ]);

        $model->description = $request->description;
        $model->course_status_id = $request->course_status_id;
        $model->update();
        return redirect("/admin/courses/list")->withSuccess('Record has been successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
