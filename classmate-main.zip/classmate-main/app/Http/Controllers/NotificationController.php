<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ParentNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class NotificationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $notifications = ParentNotification::join('students','parent_notifications.student_id','=','students.id')
            ->join('parent_students','students.id','=','parent_students.student_id')
            ->join('schedules','parent_notifications.schedule_id','=','schedules.id')
            ->join('subjects','schedules.subject_id','subjects.id')
            ->where('parent_students.parent_id',$request->session()->get('parent')['id'])
            ->select(DB::raw("
                parent_notifications.id,
                DATE_FORMAT(parent_notifications.created_at,'%m/%d/%Y %h:%i:%s %p') as `date`, 
                subjects.description as subject, 
                parent_notifications.description,
                TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
                TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
                DATE_FORMAT(parent_notifications.created_at,'%h:%i %p') as tstamp,
                parent_notifications.is_read,
                CONCAT(students.lastname,', ',students.firstname) as student
            "))
            ->orderBy(DB::raw('tstamp'), 'desc')
            ->get();

        \Debugbar::info($notifications);
        return view('parents.notifications.list',['notifications' => $notifications]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $model = ParentNotification::find($id);
        $model->is_read = 1;
        $model->update();

        $notification = ParentNotification::join('students','parent_notifications.student_id','=','students.id')
        ->join('parent_students','students.id','=','parent_students.student_id')
        ->join('schedules','parent_notifications.schedule_id','=','schedules.id')
        ->join('subjects','schedules.subject_id','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','=','dow.id')
        ->where('parent_notifications.id',$id)
        ->select(DB::raw("
            parent_notifications.id,
            DATE_FORMAT(parent_notifications.created_at,'%m/%d/%Y %h:%i:%s %p') as `date`, 
            subjects.description as subject, 
            parent_notifications.description,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            DATE_FORMAT(parent_notifications.created_at,'%h:%i %p') as tstamp,
            parent_notifications.is_read,
            CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
            dow.description as `day`,
            CONCAT(students.lastname,', ',students.firstname) as student
        "))->first();
        
        \Debugbar::info($notification);

        return view('parents.notifications.view',['notification' => $notification]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
