<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ParentModel;
use App\Models\Student;
use App\Models\StudentSchedule;
use App\Models\ParentNotification;
use App\Models\ParentStudent;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ParentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $parents = ParentModel::join('parent_status','parents.parent_status_id','=','parent_status.id')
        ->get(['parents.*','parent_status.description as status']);

        \Debugbar::info($parents);
        return view('admins.parents.list',['parents' => $parents]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admins.parents.create');
    }

    public function dashboard(Request $request)
    {
        if($request->session()->get('parent')['pword_reset'] == 1 ) {
            return redirect()->route('parent.changepw');
        }

        // $parents = ParentModel::all();
        $notif = ParentNotification::join('students','parent_notifications.student_id','=','students.id')
            ->join('parent_students','students.id','=','parent_students.student_id')
            ->where('parent_students.parent_id',$request->session()->get('parent')['id'])
            ->where('parent_notifications.is_read',0)
            ->count();
        \Debugbar::info($notif);
        return view('parents.dashboard',['notif' => $notif]);
    }

    public function students(Request $request) {
        $students = Student::join('student_status','students.student_status_id','=','student_status.id')
            ->join('courses','students.course_id','=','courses.id')
            ->join('parent_students','parent_students.student_id','=','students.id')
            ->where('parent_students.parent_id','=',$request->session()->get('parent')['id'])
            ->get(['students.*','student_status.description as status','courses.description as course']);
        

        return view("parents.students.list",['students'=>$students]);
    }

    public function changepw(Request $request) {
        return view('parents.changepw');
    }

    public function storeChange(Request $request) {
        $parent = ParentModel::find($request->session()->get('parent')['id']);

        if(!Hash::check($request->current_password,$parent->pword)) {
            return redirect()->back()->with('fail','Your current password is incorrect.');
        }

        $validated = $request->validate([
            'password' => ['required', 'max:50','min:8','confirmed'],
            'password_confirmation' => ['required'],
        ]);

        $parent->pword = Hash::make($request->password);
        $parent->pword_reset = 0;
        $parent->update();

        $request->session()->forget('parent');
        $request->session()->flush();
        return redirect()->route('login')->with('success','Your have successfully changed your password. Please login your account');;
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'email' => ['required','unique:students','unique:users','unique:professors','email','unique:parents'],
            'contactNo' => ['required', 'max:10','regex:/^[0-9]{1,20}$/'],
            'parent_status_id' => ['required'],
        ]);

        $model = new ParentModel;
        $model->firstname = $request->firstname;
        $model->middlename = $request->middlename;
        $model->lastname = $request->lastname;
        $model->email = $request->email;
        $model->contactNo = $request->contactNo;
        $model->parent_status_id = $request->parent_status_id;
        $model->pword = Hash::make($request->email);
        $model->pword_reset = 1;
        $model->save();

        return redirect("/admin/parents/list")->withSuccess('Record has been successfully saved');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $student = Student::join('student_status','students.student_status_id','=','student_status.id')
        ->join('courses','students.course_id','=','courses.id')
        ->where('students.id',$id)
        ->first(['students.*','student_status.description as status','courses.description as course']);

        $schedules = StudentSchedule::join('schedules','student_schedules.schedule_id','=','schedules.id')
            ->join('subjects','schedules.subject_id','=','subjects.id')
            ->join('dow','schedules.dow_id','dow.id')
            ->join('student_schedule_status','student_schedules.student_schedule_status_id','=','student_schedule_status.id')
            ->join('professors','schedules.professor_id','=','professors.id')
            ->where('student_schedules.student_id','=',$id)
            ->select(DB::raw("
                student_schedules.id as id,
                subjects.description as subject,
                dow.description as day,
                CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
                student_schedule_status.description as status,
                TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
                TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
                TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes
            "))->get();

        return view('parents.students.view',[
            'student' => $student,
            'schedules' => $schedules,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $parent = ParentModel::find($id);
        return view('admins.parents.edit',['parent' => $parent]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'email' => ['required','email'],
            'contactNo' => ['required', 'max:10','regex:/^[0-9]{1,20}$/'],
            'parent_status_id' => ['required'],
        ]);

        $model = ParentModel::find($request->id);
        $model->firstname = $request->firstname;
        $model->middlename = $request->middlename;
        $model->lastname = $request->lastname;
        $model->email = $request->email;
        $model->contactNo = $request->contactNo;
        $model->parent_status_id = $request->parent_status_id;
        $model->save();

        return redirect("/admin/parents/list")->withSuccess('Record has been successfully updated');
    }

    public function logout(Request $request) {
        $request->session()->forget('parent');
        $request->session()->flush();
        return redirect()->route('login');
    }
    
    public function account() {
        return view('parents.account');
    }

    public function view(string $id) {
        $parent = ParentModel::join('parent_status','parents.parent_status_id','=','parent_status.id')
            ->where('parents.id',$id)
            ->first(['parents.*','parent_status.description as status']);

        $students = ParentStudent::join('students','parent_students.student_id','students.id')
            ->join('courses','students.course_id','=','courses.id')
            ->where('parent_students.parent_id',$id)
            ->get(['students.*','courses.description as course']);

        \Debugbar::info($parent);

        return view('admins.parents.view', ['parent' => $parent,'students' => $students]);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
