<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ParentStudent;
class ParentStudentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $ps = ParentStudent::where([
            'student_id' => $request->student_id,
            'parent_id' => $request->parent_id
        ])->get();

        if($ps->isEmpty()) {
            $model = new ParentStudent();
            $model->student_id = $request->student_id;
            $model->parent_id = $request->parent_id;
            $model->save();

            return [
                'success' => true,
                'data' => $model
            ];
        }
        return [
            'success' => false,
            'data' => []
        ];
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        $model = ParentStudent::find($request->id);
        $model->delete();
        return [
            'success' => true,
            'message' => "Record has been successfully deleted"
        ];
    }
}
