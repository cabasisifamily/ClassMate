<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Professor;
use App\Models\Schedule;
use App\Models\Student;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\StudentSchedule;
use App\Models\Timekeeping;
use App\Models\ParentNotification;
use Carbon\Carbon;
use App\Http\Controllers\ReportController;

class ProfessorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $professors = Professor::join('professor_status','professors.professor_status_id','=','professor_status.id')
            ->get(['professors.*','professor_status.description as status']);
        return view('admins.professors.list',['professors'=>$professors]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admins.professors.create');
    }

    public function login() {
        return redirect()->route('login');
    }

    public function tryLogin(Request $request) {
        $professor = Professor::where('email',$request->email)->first();

        if(!$professor || !Hash::check($request->pword,$professor->pword)) {
            return redirect()->back()->with('fail','Invalid credentials, Please try again.');
        }

        $request->session()->put('professor', $professor);

        return redirect('/professor/dashboard');
    }

    public function logout(Request $request) {
        $request->session()->forget('professor');
        $request->session()->flush();
        return redirect()->route('login');
    }

    public function dashboard(Request $request) {

        $schedules = Schedule::join('subjects','schedules.subject_id','=','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('schedule_status','schedules.schedule_status_id','=','schedule_status.id')
        ->join('sections','schedules.section_id','=','sections.id')
        ->where('schedules.professor_id','=',$request->session()->get('professor')['id'])
        ->where('schedules.schedule_status_id','=',1)
        ->where('dow.num',DB::raw("DAYOFWEEK(NOW())"))        
        ->select(DB::raw("schedules.*,
            schedule_status.description as status,
            CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
            dow.description as day,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes,
            subjects.description as subject,
            sections.description as section"))->get();

        if($request->session()->get('professor')['pword_reset'] == 1 ) {
            return redirect()->route('professor.changepw');
        }
            
        return view('professors.dashboard',['schedules' => $schedules]);
    }

    public function change(Request $request) {
        return view('professors.changepw');
    }

    public function storeChange(Request $request) {
        $prof = Professor::find($request->session()->get('professor')['id']);

        if(!Hash::check($request->current_password,$prof->pword)) {
            return redirect()->back()->with('fail','Your current password is incorrect.');
        }

        $validated = $request->validate([
            'password' => ['required', 'max:50','min:8','confirmed'],
            'password_confirmation' => ['required'],
        ]);

        $prof->pword = Hash::make($request->password);
        $prof->pword_reset = 0;
        $prof->update();

        $request->session()->forget('professor');
        $request->session()->flush();
        return redirect()->route('login')->with('success','Your have successfully changed your password. Please login your account');;
    }

    public function schedules(Request $request) {
        $schedules = Schedule::join('subjects','schedules.subject_id','=','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('schedule_status','schedules.schedule_status_id','=','schedule_status.id')
        ->where('schedules.professor_id','=',$request->session()->get('professor')['id'])
        ->join('sections','schedules.section_id','=','sections.id')        
        ->select(DB::raw("schedules.*,
            schedule_status.description as status,
            CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
            dow.description as day,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes,
            subjects.description as subject,
            sections.description as section"))->get();

        return view('professors.schedules',['schedules' => $schedules]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'email' => ['required','unique:students','unique:users','unique:professors','email'],
            'birthday' => ['required', 'max:20','date','date_format:Y-m-d'],
            'contactNo' => ['required', 'max:10','regex:/^[0-9]{1,20}$/'],
            'professor_status_id' => ['required'],
        ]);

        $model = new Professor;
        $model->firstname = $request->firstname;
        $model->middlename = $request->middlename;
        $model->lastname = $request->lastname;
        $model->email = $request->email;
        $model->birthday = $request->birthday;
        $model->contactNo = $request->contactNo;
        $model->professor_status_id = $request->professor_status_id;
        $model->pword = Hash::make($request->email);
        $model->pword_reset = 1;
        $model->save();

        return redirect("/admin/professors/list")->withSuccess('Record has been successfully saved');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $professor = Professor::join('professor_status','professors.professor_status_id','=','professor_status.id')
            ->where('professors.id',$id)
            ->first(['professors.*','professor_status.description as status']);

        $schedules = Schedule::join('subjects','schedules.subject_id','=','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('schedule_status','schedules.schedule_status_id','=','schedule_status.id')
        ->where('schedules.professor_id','=',$id)
        ->select(DB::raw("schedules.*,
            schedule_status.description as status,
            CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
            dow.description as day,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes,
            subjects.description as subject"))->get();
        
        return view('admins.professors.view',[
            'professor'=>$professor,
            'schedules'=>$schedules
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $professor = Professor::find($id);
        return view('admins.professors.edit',['professor'=>$professor]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'email' => ['required'],
            'birthday' => ['required', 'max:20','date','date_format:Y-m-d'],
            'contactNo' => ['required', 'max:10','regex:/^[0-9]{1,20}$/'],
            'professor_status_id' => ['required'],
        ]);

        $model = Professor::find($id);

        $model->firstname = $request->firstname;
        $model->middlename = $request->middlename;
        $model->lastname = $request->lastname;
        $model->email = $request->email;
        $model->birthday = $request->birthday;
        $model->contactNo = $request->contactNo;
        $model->professor_status_id = $request->professor_status_id;
        $model->update();
        return redirect("/admin/professors/{$model->id}/view")->withSuccess('Record has been successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function view(Request $request,string $id)
    {
        $schedule = Schedule::join('subjects','schedules.subject_id','=','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('schedule_status','schedules.schedule_status_id','=','schedule_status.id')
        ->where('schedules.professor_id','=',$request->session()->get('professor')['id'])
        ->where('schedules.id','=',$id)
        ->select(DB::raw("schedules.*,
            schedule_status.description as status,
            CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
            dow.description as day,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes,
            subjects.description as subject"))->first();

        $students = Schedule::join('student_schedules','schedules.id','=','student_schedules.schedule_id')
            ->join('students','student_schedules.student_id','=','students.id')
            ->where('student_schedules.schedule_id','=',$id)
            ->get(['students.*']);

        return view('professors.schedules.view',[
            'schedule' => $schedule,
            'students' => $students,
        ]);
    }

    public function addStudent(string $id) {
        return view('professors.schedules.add-student',['scheduleId' => $id]);
    }

    public function storeStudent(Request $request) {
        $validated = $request->validate([
            'firstname' => ['required', 'max:100'],
            'lastname' => ['required', 'max:100'],
            'birthday' => ['required', 'max:20'],
            'contactNo' => ['required', 'max:50'],
            'rfid' => ['required'],
            'student_id' => ['required'],
            'schedule_id' => ['required'],
        ]);

        $schedule = StudentSchedule::where([
            'student_id' => $request->student_id,
            'schedule_id' => $request->schedule_id
        ])->first();

        if($schedule) {
            return redirect()->back()->withFail('Student already exists.');
        }
        
        $model = new StudentSchedule;
        $model->student_id = $request->student_id;
        $model->schedule_id = $request->schedule_id;
        $model->student_schedule_status_id = 1;
        $model->save();
        return redirect("/professor/schedules/{$request->schedule_id}/view")->withSuccess('Record has been successfully added');
    }

    public function getStudent(string $rfid) {
        return Student::where('rfid',$rfid)->first();
    }

    public function timekeeping(Request $request, $id) {

        $schedule = Schedule::join('subjects','schedules.subject_id','=','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('schedule_status','schedules.schedule_status_id','=','schedule_status.id')
        ->where('schedules.professor_id','=',$request->session()->get('professor')['id'])
        ->where('schedules.id','=',$id)
        ->select(DB::raw("schedules.*,
            schedule_status.description as status,
            CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
            dow.description as day,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes,
            subjects.description as subject"))->first();

        return view('professors.timekeeping.index', ['schedule' => $schedule]);
    }

    public function getActivity($scheduleId) {

        $result = StudentSchedule::where('student_schedules.schedule_id',$scheduleId)
            ->join('students','student_schedules.student_id','=','students.id')
            ->select(DB::raw("
                students.picture,
                CONCAT(students.lastname,', ',students.firstname,' ',IFNULL(students.middlename,'')) AS name,
                students.id as student_id,
                DATE_FORMAT((
                    SELECT IF(tk.timein IS NOT NULL,CONCAT(CURDATE(),' ',tk.timein),NULL)
                    FROM timekeeping tk 
                    WHERE tk.student_id = students.id AND 
                    tk.schedule_id = student_schedules.schedule_id 
                    AND DATE(tk.created_at) = CURDATE()
                ),'%h:%i:%s %p') AS timein,
                DATE_FORMAT((
                    SELECT IF(tk.timeout IS NOT NULL,CONCAT(CURDATE(),' ',tk.timeout),NULL) 
                    FROM timekeeping tk 
                    WHERE tk.student_id = students.id AND 
                    tk.schedule_id = student_schedules.schedule_id 
                    AND DATE(tk.created_at) = CURDATE()
                ),'%h:%i:%s %p') AS timeout,
                (
                    SELECT  CASE
                                WHEN tk.is_absent IS NOT NULL THEN 'Absent'
                                WHEN TIMESTAMPDIFF(MINUTE, schedules.start_time, tk.created_at) > 10 THEN 'Late'
                                WHEN TIME(tk.created_at) >= schedules.start_time THEN 'Present'
                            END
                    FROM timekeeping tk INNER JOIN schedules ON tk.schedule_id = schedules.id
                    WHERE tk.student_id = students.id AND DATE(tk.created_at) = CURDATE() AND tk.schedule_id = student_schedules.schedule_id
                ) AS status
            "))->get();

        if(empty($result)) {
            return [
                'success' => false,
                'data' => []
            ];
        }

        return [
            'success' => true,
            'data' => $result
        ];
    }

    public function storeTime(Request $request) {
        $studentId = $this->getStudentByRFID($request->rfid);
        $scheduleId = $request->schedule_id;

        if(!$this->isScheduleAvailable($scheduleId)) {
            return ['success' => false,'message' => 'Schedule unavailable, try again later.'];
        }

        if($this->checkIfAbsent($studentId,$scheduleId)) {
            return ['success' => false,'message' => 'Timein request denied: student is absent.'];
        }

        if($studentId) {
            $studentSchedule = $this->getStudentSchedule($studentId,$scheduleId);
            if(!empty($studentSchedule)) {
                
                $timeIn = $this->hasTimein($studentId, $scheduleId);

                if($timeIn) {
                    $currentDate = Carbon::now()->toDateString();
                    $timekeeping = Timekeeping::where(['student_id' => $studentId,'schedule_id' => $scheduleId])->whereDate('created_at', '=', $currentDate)->first();
                    
                    if($timekeeping) {
                        $timekeeping->timeout = now();
                        $timekeeping->update();

                        $this->storeNotification([
                            'description' => 'Time out',
                            'student_id' => $studentId,
                            'schedule_id' => $scheduleId
                        ]);

                        return ['success' => true,'message' => 'Timeout confirmation received.'];
                    }

                } else {
                    $timekeeping = new Timekeeping;
                    $timekeeping->schedule_id = $scheduleId;
                    $timekeeping->student_id = $studentId;
                    $timekeeping->timein = now();
                    $timekeeping->save();

                    $description = $this->isLate($scheduleId) ? 'Time in (Late)':'Time in (On Time)';

                    $this->storeNotification([
                        'description' => $description,
                        'student_id' => $studentId,
                        'schedule_id' => $scheduleId
                    ]);

                    return ['success' => true,'message' => 'Timein confirmation received.'];
                }

            } else {
                return [
                    'success' => false,
                    'message' => "The student is not registered for this subject."
                ];
            }
        } else {
            return [
                'success' => false,
                'message' => 'Student record not found.'
            ];
        }


        

    }

    public function hasTimein($studentId,$scheduleId) {
        $today = Carbon::now()->toDateString();
        $tk = Timekeeping::where([
                'student_id' => $studentId,
                'schedule_id' => $scheduleId,
        ])->whereDate('created_at', $today)->first();

        if(empty($tk)) {
            return false;
        }

        return true;
    }

    public function checkIfAbsent($studentId,$scheduleId) {
        $today = Carbon::now()->toDateString();
        $tk = Timekeeping::where([
                'student_id' => $studentId,
                'schedule_id' => $scheduleId,
                'is_absent' => 1
        ])->whereDate('created_at', $today)->first();

        if(empty($tk)) {
            return false;
        }

        return true;
    }

    public function hasTimeout($studentId,$scheduleId) {
        $tk = Timekeeping::where([
                'student_id' => $studentId,
                'schedule_id' => $scheduleId,
            ]);

        if(empty($tk)) {
            return false;
        }
        
        return true;
    }

    public function markAbsent(Request $request) {
        $timekeeping = new Timekeeping;
        $timekeeping->schedule_id = $request->schedule_id;
        $timekeeping->student_id = $request->student_id;
        $timekeeping->is_absent = 1;
        $timekeeping->save();

        $this->storeNotification([
            'description' => 'Marked as Absent',
            'student_id' => $request->student_id,
            'schedule_id' => $request->schedule_id
        ]);

        return ['success' => true,'message' => 'Mark absent confirmation received.'];
    }

    public function getStudentByRFID($rfid) {
        $student = Student::where('rfid',$rfid)->first();
        if(empty($student)) {
            return false; 
        }
        return $student->id;
    }

    public function getStudentSchedule($studentId,$scheduleId) {
        return StudentSchedule::where(['student_id' => $studentId,'schedule_id' => $scheduleId])->first();
    }

    public function logs(Request $request) {
        $logs = [];
        $report = new ReportController;

        if($request->input('date') && $request->input('schedule_id')) {
            $logs = $report->getLogs(md5($request->input('schedule_id')),$request->input('date'));
        }
        \Debugbar::info($logs);

        $schedules = Schedule::join('subjects','schedules.subject_id','=','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('schedule_status','schedules.schedule_status_id','=','schedule_status.id')
        ->join('sections','schedules.section_id','=','sections.id')
        ->where('schedules.professor_id','=',$request->session()->get('professor')['id'])
        ->where('schedules.schedule_status_id','=',1)        
        ->select(DB::raw("schedules.*,
            schedule_status.description as status,
            CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
            dow.description as day,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes,
            subjects.description as subject,
            sections.description as section"))->get();

        return view('professors.logs',[
            'schedules' => $schedules,
            'logs' => $logs
        ]);
    }

    public function accounts() {
        return view('professors.account');
    }

    public function storeNotification($data) {
        $model = new ParentNotification();
        $model->description = $data['description'];
        $model->student_id = $data['student_id'];
        $model->schedule_id = $data['schedule_id'];
        $model->is_read = 0;

        if($model->save()) {
            return true;
        }

        return false;
    }

    public function isLate($scheduleId) {
        $data = Schedule::where('id','=',$scheduleId)
            ->select(DB::raw("
                IF(TIMESTAMPDIFF(MINUTE, start_time, CURRENT_TIME()) > 10, 2, 1) as result
            "))->first();

        \Debugbar::info($data);

        if($data->result == 1) {
            return false;
        }

        return true;
    }

    public function isScheduleAvailable($scheduleId) {
        $result = Schedule::join('dow', 'schedules.dow_id', '=', 'dow.id')
        ->select(DB::raw('schedules.*'))
        ->where('schedules.id',$scheduleId)
        ->where('dow.num', '=', DB::raw('DAYOFWEEK(NOW())'))
        ->where('schedules.start_time', '<=', DB::raw('CURTIME()'))
        ->where('schedules.end_time', '>=', DB::raw('CURTIME()'))
        ->count();

        if($result == 1) {
            return true;
        }

        return false;
    }
}
 