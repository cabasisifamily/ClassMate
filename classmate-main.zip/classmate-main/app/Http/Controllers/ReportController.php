<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use FPDF;
use App\Models\StudentSchedule;
use App\Models\Schedule;
use Illuminate\Support\Facades\DB;

use Rap2hpoutre\FastExcel\FastExcel;
use OpenSpout\Common\Entity\Style\Style;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $date = $request->input('date');
        $scheduleId = $request->input('schedule_id');

        $logs = $this->getLogs($scheduleId,$date);
        $scheduleDetails = $this->getScheduleDetails($scheduleId);

        if(!empty($logs)) {
            return $this->generate($logs,$scheduleDetails,$date);
        }

        return "Not result found";

      
    }

    public function excel(Request $request) {
        $date = $request->input('date');
        $scheduleId = $request->input('schedule_id');

        $logs = $this->getLogs($scheduleId,$date);
        $scheduleDetails = $this->getScheduleDetails($scheduleId);

        $header_style = (new Style())->setFontBold();

        if(!empty($logs)) {
            return (new FastExcel($logs))
                ->headerStyle($header_style)
                ->download("report-{$scheduleId}-{$date}.xlsx", function($line) {
                return [
                    'Student Number' => $line->student_number,
                    'Full Name' => $line->name,
                    'Section' => $line->section,
                    'Subject' => $line->subject,
                    'Schedule' => $line->stime . '-' . $line->etime,
                    'Time In' => $line->timein,
                    'Time Out' => $line->timeout,
                    'Status' => $line->status
                ];
            });
        }
    }

    public function generate($logs,$details,$date) {

        $pdf = new CrimsonPDF();

        $pdf->AddPage();
        
        $pdf->SetFont('Arial', 'B', 9);

        $pdf->Cell(30, 6, 'Date: ' . $this->dateFormat($date),0,1);
        $pdf->Cell(30, 6, 'Professor: ' . strtoupper($details->professor),0,1);
        $pdf->Cell(30, 6, 'Schedule: ' . $details->subject . ' - ' . $details->section . ' (' . $details->stime . ' - ' . $details->etime. ')',0,1);

        $pdf->Ln(3);

        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell(30, 6, 'Student ID',1,0);
        $pdf->Cell(95, 6, 'Name',1,0);
        $pdf->Cell(20, 6, 'Time in',1,0);
        $pdf->Cell(20, 6, 'Time out',1,0);
        $pdf->Cell(30, 6, 'Status',1,1);
       
        $pdf->SetFont('Arial', '', 9);
        foreach($logs as $row) {
            $pdf->Cell(30, 6, strtoupper($row->student_number),1,0);
            $pdf->Cell(95, 6, strtoupper($row->name),1,0);
            $pdf->Cell(20, 6, $row->timein,1,0);
            $pdf->Cell(20, 6, $row->timeout,1,0);
            $pdf->Cell(30, 6, strtoupper($row->status),1,1);
        }

        $pdfContent = $pdf->Output('report.pdf', 'S');
        return response($pdfContent, 200, [
            'Content-Type' => 'application/pdf',
        ]);
    }

    public function getLogs($scheduleId,$date) {
        $results = StudentSchedule::join('students','student_schedules.student_id','=','students.id')
            ->join('schedules','student_schedules.schedule_id','=','schedules.id')
            ->join('subjects','schedules.subject_id','=','subjects.id')
            ->join('sections','schedules.section_id','=','sections.id')
            ->where(DB::raw('md5(student_schedules.schedule_id)'),$scheduleId)
            ->select(DB::raw("
                CONCAT(students.lastname,', ',students.firstname,' ',IFNULL(students.middlename,'')) AS name,
                students.id as student_id,
                DATE_FORMAT((
                    SELECT IF(tk.timein IS NOT NULL,CONCAT('{$date}',' ',tk.timein),NULL)
                    FROM timekeeping tk 
                    WHERE tk.student_id = students.id AND 
                    tk.schedule_id = student_schedules.schedule_id 
                    AND DATE(tk.created_at) = '{$date}'
                ),'%h:%i:%s %p') AS timein,
                DATE_FORMAT((
                    SELECT IF(tk.timeout IS NOT NULL,CONCAT('{$date}',' ',tk.timeout),NULL) 
                    FROM timekeeping tk 
                    WHERE tk.student_id = students.id AND 
                    tk.schedule_id = student_schedules.schedule_id 
                    AND DATE(tk.created_at) = '{$date}'
                ),'%h:%i:%s %p') AS timeout,
                (
                    SELECT  CASE
                                WHEN tk.is_absent IS NOT NULL THEN 'Absent'
                                WHEN TIMESTAMPDIFF(MINUTE, schedules.start_time, tk.created_at) > 10 THEN 'Late'
                                WHEN TIME(tk.created_at) >= schedules.start_time THEN 'Present'
                            END
                    FROM timekeeping tk INNER JOIN schedules ON tk.schedule_id = schedules.id
                    WHERE tk.student_id = students.id AND DATE(tk.created_at) = '{$date}' AND tk.schedule_id = student_schedules.schedule_id
                ) AS status,
                students.student_number,
                subjects.description as subject,
                sections.description as section,
                TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
                TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime
            "))->get();

        if(!empty($results)) {
            return $results;
        }

        return false;
    }

    public function getScheduleDetails($scheduleId) {
        $results = Schedule::join('sections','schedules.section_id','=','sections.id')
            ->join('subjects','schedules.subject_id','=','subjects.id')
            ->join('professors','schedules.professor_id','=','professors.id')
            ->where(DB::raw('md5(schedules.id)'),$scheduleId)
            ->select(DB::raw("
                CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
                TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
                TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
                sections.description as section,
                subjects.description as subject
            "))
            ->first();
        
        if(!empty($results)) {
            return $results;
        }

        return false;
    }

    public function dateFormat($date) {
        $dateTime = new \DateTime($date);
        return $formattedDate = $dateTime->format('F j, Y');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}

class CrimsonPDF extends FPDF {
    function Header() {

        $imagePath = public_path('images/logo.png'); // Get the absolute path to the image file
        $this->Image($imagePath, 32, 5, 0, 20); // Parameters: Path, X, Y, Width, Height (in millimeters)

        $this->SetFont('Arial', 'B', 16);
        $this->Cell(190, 10, 'ClassMate Attendance Report',0,1,'C');
        $this->Ln(20);

    }

    function Footer() {
        // Custom footer content for each page
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}
