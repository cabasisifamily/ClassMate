<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subject;
use App\Models\Professor;
use App\Models\Dow;
use App\Models\Schedule;
use App\Models\ScheduleStatus;
use App\Models\Section;
use Illuminate\Support\Facades\DB;

class ScheduleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $schedules = Schedule::join('subjects','schedules.subject_id','=','subjects.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('schedule_status','schedules.schedule_status_id','=','schedule_status.id')
        ->join('sections','schedules.section_id','=','sections.id')
        ->select(DB::raw("schedules.*,
            schedule_status.description as status,
            CONCAT(professors.lastname,', ',professors.firstname,' ',IFNULL(professors.middlename,'')) as professor,
            dow.description as day,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes,
            subjects.description as subject,
            sections.description as section"))->get();
        return view('admins.schedules.list',['schedules' => $schedules]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $subjects = Subject::where('subject_status_id',1)->get();
        $professors = Professor::where('professor_status_id',1)->get();
        $sections = Section::where('section_status_id',1)->get();
        $dow = Dow::all();

        return view('admins.schedules.create', [
            'subjects' => $subjects,
            'professors' => $professors,
            'dow' => $dow,
            'sections' => $sections,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'subject_id' => ['required'],
            'professor_id' => ['required'],
            'dow_id' => ['required'],
            'start_time' => ['required'],
            'end_time' => ['required'],
            'schedule_status_id' => ['required'],
            'section_id' => ['required'],
        ]);

        $model = new Schedule;
        $model->subject_id = $request->subject_id;
        $model->professor_id = $request->professor_id;
        $model->dow_id = $request->dow_id;
        $model->start_time = $request->start_time;
        $model->end_time = $request->end_time;
        $model->schedule_status_id = $request->schedule_status_id;
        $model->section_id = $request->section_id;
        $model->save();

        return redirect("/admin/schedules/list")->withSuccess('Record has been successfully saved');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $schedule = Schedule::find($id);
        $subjects = Subject::where('subject_status_id',1)->get();
        $professors = Professor::where('professor_status_id',1)->get();
        $dow = Dow::all();
        $sections = Section::where('section_status_id',1)->get();
        $scheduleStatus = ScheduleStatus::all();
        
        return view('admins.schedules.edit', [
            'subjects' => $subjects,
            'professors' => $professors,
            'dow' => $dow,
            'schedule' => $schedule,
            'scheduleStatus' => $scheduleStatus,
            'sections' => $sections,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        
        $validated = $request->validate([
            'subject_id' => ['required'],
            'professor_id' => ['required'],
            'dow_id' => ['required'],
            'start_time' => ['required'],
            'end_time' => ['required'],
            'schedule_status_id' => ['required'],
            'section_id' => ['required'],
        ]);

        $model = Schedule::find($id);
        $model->subject_id = $request->subject_id;
        $model->professor_id = $request->professor_id;
        $model->dow_id = $request->dow_id;
        $model->start_time = $request->start_time;
        $model->end_time = $request->end_time;
        $model->schedule_status_id = $request->schedule_status_id;
        $model->section_id = $request->section_id;
        $model->update();

        return redirect("/admin/schedules/list")->withSuccess('Record has been successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
