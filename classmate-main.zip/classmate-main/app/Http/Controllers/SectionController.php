<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Section;

class SectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $sections = Section::join('section_status','sections.section_status_id','=','section_status.id')
            ->get(['sections.*','section_status.description as status']);
        
        return view('admins.sections.list',['sections'=>$sections]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("admins.sections.create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $model = new Section;

        $validated = $request->validate([
            'description' => ['required','max:100','min:2','regex:/^[a-zA-Z0-9\s]+$/'],
            'section_status_id' => ['required'],
        ]);

        $model->description = $request->description;
        $model->section_status_id = $request->section_status_id;
        $model->save();

        return redirect("/admin/sections/list")->withSuccess('Record has been successfully saved');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $section = Section::find($id);
        return view("admins.sections.edit",['section' => $section]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $model = Section::find($id);

        $validated = $request->validate([
            'description' => ['required','max:100','min:2','regex:/^[a-zA-Z0-9\s]+$/'],
            'section_status_id' => ['required'],
        ]);

        $model->description = $request->description;
        $model->section_status_id = $request->section_status_id;
        $model->update();
        return redirect("/admin/sections/list")->withSuccess('Record has been successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
