<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use App\Models\StudentSchedule;
use App\Models\Timekeeping;
use App\Models\Course;
use App\Models\ParentModel;
use App\Models\ParentStudent;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {

            $students = Student::join('student_status','students.student_status_id','=','student_status.id')
            ->join('courses','students.course_id','=','courses.id')
            ->get(['students.*','student_status.description as status','courses.description as course']);

            // \Debugbar::info($students);

            return view('admins.students.list',['students'=>$students]);

        } catch(Exception $e) {
            Debugbar::addThrowable($e);
        }
        
    }

    public function login() {
        return redirect()->route('login');
    }

    public function tryLogin(Request $request) {

        $validated = $request->validate([
            'email' => ['required'],
            'pword' => ['required'],
        ], [
            'pword.required' => 'The password field is required.'
        ]);

        $student = Student::where('email',$request->email)->first();

        if(!$student || !Hash::check($request->pword,$student->pword)) {
            return redirect()->back()->with('fail','Invalid credentials, Please try again.');
        }

        $request->session()->put('student', $student);

        return redirect('/student/dashboard');
    }

    public function logout(Request $request) {
        $request->session()->forget('student');
        $request->session()->flush();
        return redirect()->route('login');
    }


    public function dashboard(Request $request) {

        if($request->session()->get('student')['pword_reset'] == 1 ) {
            return redirect()->route('student.changepw');
        }

        $schedules = StudentSchedule::join('schedules','student_schedules.schedule_id','=','schedules.id')
            ->join('subjects','schedules.subject_id','=','subjects.id')
            ->join('dow','schedules.dow_id','dow.id')
            ->join('student_schedule_status','student_schedules.student_schedule_status_id','=','student_schedule_status.id')
            ->join('professors','schedules.professor_id','=','professors.id')
            ->where('student_schedules.student_id','=',$request->session()->get('student')['id'])
            ->where('dow.num','=',$this->getDayOfWeek())
            ->select(DB::raw("
                student_schedules.id as id,
                subjects.description as subject,
                dow.description as day,
                CONCAT(professors.lastname,', ',professors.firstname,' ',IFNULL(professors.middlename,'')) as professor,
                student_schedule_status.description as status,
                TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
                TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
                TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes
            "))->get();

        return view('students.dashboard',['schedules' => $schedules]);
    }

    public function schedules(Request $request) {
        $schedules = StudentSchedule::join('schedules','student_schedules.schedule_id','=','schedules.id')
        ->join('subjects','schedules.subject_id','=','subjects.id')
        ->join('dow','schedules.dow_id','dow.id')
        ->join('student_schedule_status','student_schedules.student_schedule_status_id','=','student_schedule_status.id')
        ->join('professors','schedules.professor_id','=','professors.id')
        ->where('student_schedules.student_id','=',$request->session()->get('student')['id'])
        ->select(DB::raw("
            student_schedules.id as id,
            subjects.description as subject,
            dow.description as day,
            CONCAT(professors.lastname,', ',professors.firstname,' ',IFNULL(professors.middlename,'')) as professor,
            student_schedule_status.description as status,
            TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
            TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
            TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes
        "))->get();

        \Debugbar::info($schedules);

        return view('students.schedules',['schedules' => $schedules]);
    }

    public function getDayOfWeek() {
        date_default_timezone_set('Asia/Manila');
        return Date('N') + 1;
    }

    public function changepw() {
        return  view('students.changepw');
    }

    public function storeChange(Request $request) {

        $student = Student::find($request->session()->get('student')['id']);

        if(!Hash::check($request->current_password,$student->pword)) {
            return redirect()->back()->with('fail','Your current password is incorrect.');
        }

        $validated = $request->validate([
            'password' => ['required', 'max:50','min:8','confirmed'],
            'password_confirmation' => ['required'],
        ]);

        $student->pword = Hash::make($request->password);
        $student->pword_reset = 0;
        $student->update();

        $request->session()->forget('student');
        $request->session()->flush();
        return redirect()->route('login')->with('success','Your have successfully changed your password. Please login your account');

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $courses = Course::all();
        return view('admins.students.create',['courses' => $courses]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'email' => ['required','unique:students','unique:users','unique:professors','email'],
            'birthday' => ['required', 'max:20','date','date_format:Y-m-d'],
            'address' => ['required','min:10','max:255'],
            'contactNo' => ['required', 'max:10','min:10','regex:/^[0-9]{1,20}$/'],
            'contactPerson' => ['required', 'max:50','regex:/^[a-zA-Z\s]+$/'],
            'rfid' => ['required', 'max:100','unique:students'],
            'student_status_id' => ['required'],
            'course_id' => ['required'],
            'student_number' => ['required'],
            'picture' => ['required','file','mimes:jpg,jpeg,png']
        ]);

        $model = new Student;
        $model->firstname = $request->firstname;
        $model->middlename = $request->middlename;
        $model->lastname = $request->lastname;
        $model->birthday = $request->birthday;
        $model->contactNo = $request->contactNo;
        $model->contactPerson = $request->contactPerson;
        $model->address = $request->address;
        $model->email = $request->email;
        $model->student_status_id = $request->student_status_id;
        $model->pword = Hash::make($request->email);
        $model->pword_reset = 1;
        $model->rfid = $request->rfid;
        $model->course_id = $request->course_id;
        $model->student_number = $request->student_number;
        
        $file = $request->file('picture');
        $path = $file->store('public');
        $url = asset('storage/' . $file->hashName());

        $model->picture = $file->hashName();

        if($model->save()) {
            return redirect()->route('admin.students.list')->with('success','Record has been successfully added.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $student = Student::join('student_status','students.student_status_id','=','student_status.id')
        ->join('courses','students.course_id','=','courses.id')
        ->where('students.id',$id)
        ->first(['students.*','student_status.description as status','courses.description as course']);

        $schedules = StudentSchedule::join('schedules','student_schedules.schedule_id','=','schedules.id')
            ->join('subjects','schedules.subject_id','=','subjects.id')
            ->join('dow','schedules.dow_id','dow.id')
            ->join('student_schedule_status','student_schedules.student_schedule_status_id','=','student_schedule_status.id')
            ->join('professors','schedules.professor_id','=','professors.id')
            ->where('student_schedules.student_id','=',$id)
            ->select(DB::raw("
                student_schedules.id as id,
                subjects.description as subject,
                dow.description as day,
                CONCAT(professors.lastname,', ',professors.firstname,' ',professors.middlename) as professor,
                student_schedule_status.description as status,
                TIME_FORMAT(STR_TO_DATE(schedules.start_time, '%H:%i:%s'), '%h:%i %p') as stime,
                TIME_FORMAT(STR_TO_DATE(schedules.end_time, '%H:%i:%s'), '%h:%i %p') as etime,
                TIMESTAMPDIFF(MINUTE, STR_TO_DATE(start_time, '%H:%i'), STR_TO_DATE(end_time, '%H:%i')) AS total_minutes
            "))->get();
        
        $parents = ParentModel::all();
        $guardian = ParentStudent::join('parents','parent_students.parent_id','=','parents.id')
        ->where('parent_students.student_id',$id)
        ->get(['parents.*','parent_students.id as ps_id']);

        return view('admins.students.view',[
            'student' => $student,
            'schedules' => $schedules,
            'parents' => $parents,
            'guardian' => $guardian
        ]);
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $student = Student::where('id',$id)->first();
        $courses = Course::all();
        return view('admins.students.edit',['student' => $student,'courses' => $courses]);
    }

    public function account()
    {
        return view('students.account');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {

        $rules = [
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'email' => ['required'],
            'birthday' => ['required', 'max:20','date','date_format:Y-m-d'],
            'address' => ['required','min:10','max:255'],
            'contactNo' => ['required', 'max:10','regex:/^[0-9]{1,20}$/'],
            'contactPerson' => ['required', 'max:50','regex:/^[a-zA-Z\s]+$/'],
            'rfid' => ['required', 'max:100'],
            'student_status_id' => ['required'],
            'course_id' => ['required'],
            'student_number' => ['required'],
        ];

        
        $model = Student::find($id);
        
        
        if($request->hasFile('picture')) {

            $rules['picture'] = ['required','file','mimes:jpg,jpeg,png'];
            
            $existingPicture = $model->picture;

            $file = $request->file('picture');
            $path = $file->store('public');
            $url = asset('storage/' . $file->hashName());

            if(Storage::exists('public/'.$existingPicture)) {
                Storage::delete('public/' . $existingPicture);
            }

            $model->picture = $file->hashName();
        }
        
        $validated = $request->validate($rules);

        $model->firstname = $request->firstname;
        $model->middlename = $request->middlename;
        $model->lastname = $request->lastname;
        $model->birthday = $request->birthday;
        $model->contactNo = $request->contactNo;
        $model->contactPerson = $request->contactPerson;
        $model->address = $request->address;
        $model->email = $request->email;
        $model->student_status_id = $request->student_status_id;
        $model->course_id = $request->course_id;
        $model->student_number = $request->student_number;

        if($request->rfid != $model->rfid) {
            $model->rfid = $request->rfid;
        }

        $model->update();
        return redirect("/admin/students/{$request->id}/view")->withSuccess('Record has been successfully updated');

    }

    public function logs(Request $request,$scheduleId) {
        $logs = Timekeeping::join('student_schedules','timekeeping.schedule_id','=','student_schedules.schedule_id')
            ->join('schedules','student_schedules.schedule_id','=','schedules.id')
            ->where('timekeeping.student_id',$request->session()->get('student')['id'])
            ->where('student_schedules.id','=',$scheduleId)
            ->select(DB::raw("
                timekeeping.id,DATE_FORMAT(timekeeping.created_at,'%M %e, %Y') AS date, 
                IF(timekeeping.is_absent > 0,'Absent',DATE_FORMAT(timein,'%h:%i:%s %p')) AS timein, 
                IF(timekeeping.is_absent > 0,'Absent',DATE_FORMAT(timeout,'%h:%i:%s %p')) AS timeout,
                IF(timekeeping.is_absent > 0,'Absent',IF(timekeeping.timein > schedules.start_time,'Late','On Time')) AS description
            "))
            ->get();

        return view('students.logs',['logs' => $logs]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
