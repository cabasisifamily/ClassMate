<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subject;

class SubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $subjects = Subject::join('subject_status','subjects.subject_status_id','=','subject_status.id')
            ->get(['subjects.*','subject_status.description as status']);
        return view('admins.subjects.list',['subjects'=>$subjects]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("admins.subjects.create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $model = new Subject;

        $validated = $request->validate([
            'description' => ['required','max:100','min:2','regex:/^[a-zA-Z0-9\s]+$/'],
            'subject_status_id' => ['required'],
        ]);

        $model->description = $request->description;
        $model->subject_status_id = $request->subject_status_id;
        $model->save();

        return redirect("/admin/subjects/list")->withSuccess('Record has been successfully saved');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $subject = Subject::find($id);
        return view("admins.subjects.edit",['subject' => $subject]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $model = Subject::find($id);

        $validated = $request->validate([
            'description' => ['required','max:100','min:2','regex:/^[a-zA-Z0-9\s]+$/'],
            'subject_status_id' => ['required'],
        ]);

        $model->description = $request->description;
        $model->subject_status_id = $request->subject_status_id;
        $model->update();
        return redirect("/admin/subjects/list")->withSuccess('Record has been successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
