<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Professor;
use App\Models\Student;
use App\Models\ParentModel;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $users = User::all();
        $users = User::join('user_roles','users.user_role_id','=','user_roles.id')
            ->join('user_status','users.user_status_id','=','user_status.id')
            ->get(['users.*','user_roles.description as role','user_status.description as status']);
        return view('admins.users.list',['users'=>$users]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admins.users.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'email' => ['required','unique:students','unique:users','unique:professors','email'],
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'user_role_id' => ['required'],
            'user_status_id' => ['required'],
        ]);

        $model = new User;
        $model->first_name = $request->firstname;
        $model->middle_name = $request->middlename ?? '';
        $model->last_name = $request->lastname;
        $model->email = $request->email;
        $model->user_status_id = $request->user_status_id;
        $model->user_role_id = $request->user_role_id;
        $model->pword = Hash::make($request->email);
        $model->pword_reset = 1;

        if($model->save()) {
            return redirect()->route('admin.users.list')->with('success','Record has been successfully added.');
        }
    }

    public function loginUI() {
        return view('login');
    }

    public function login(Request $request) {

        $validated = $request->validate([
            'email' => ['required'],
            'pword' => ['required'],
        ],['pword.required' => 'The password field is required.']);


        if($user = $this->checkIfuser($request)) {
            $request->session()->put('user', $user);
            return redirect('/admin/dashboard');
        }  else {
            if($professor = $this->checkIfProfessor($request)) {
                $request->session()->put('professor', $professor);
                return redirect('/professor/dashboard');
            } else {
                if($student = $this->checkIfStudent($request)) {
                    $request->session()->put('student', $student);
                    return redirect('/student/dashboard');
                } else {
                    if($parent = $this->checkIfParent($request)) {
                        $request->session()->put('parent', $parent);
                        return redirect('/parent/dashboard');
                    } else {
                        return redirect()->back()->with('fail','Invalid credentials, Please try again.');
                    }
                }
            }
        }
    }

    private function checkIfuser(Request $request) {

        $user = User::where('email',$request->email)
            ->where('user_status_id',1)
            ->first();

        \Debugbar::info(['user' => $user]);

        if(!$user || !Hash::check($request->pword,$user->pword)) {
            return false;
        }
        
        return $user;
    }

    private function checkIfProfessor(Request $request) {

        $prof = Professor::where('email',$request->email)
            ->where('professor_status_id',1)
            ->first();

        \Debugbar::info(['prof' => $prof]);

        if(!$prof || !Hash::check($request->pword,$prof->pword)) {
            return false;
        }
        
        return $prof;
    }

    private function checkIfStudent(Request $request) {

        $student = Student::where('email',$request->email)
            ->where('student_status_id',1)
            ->first();

        \Debugbar::info(['student' => $student]);

        if(!$student || !Hash::check($request->pword,$student->pword)) {
            return false;
        }
        
        return $student;
    }

    private function checkIfParent(Request $request) {

        $parent = ParentModel::where('email',$request->email)
            ->where('parent_status_id',1)
            ->first();

        \Debugbar::info(['parent' => $parent]);

        if(!$parent || !Hash::check($request->pword,$parent->pword)) {
            return false;
        }
        
        return $parent;
    }

    public function logout(Request $request) {
        $request->session()->forget('user');
        $request->session()->flush();
    return redirect()->route('login');
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
       //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $user = User::find($id);
        return view('admins.users.edit',['user' => $user]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validated = $request->validate([
            'email' => ['required'],
            'firstname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'middlename' => ['max:30','regex:/^[a-zA-Z\s]+$/'],
            'lastname' => ['required', 'max:30','regex:/^[a-zA-Z\s]+$/'],
            'user_role_id' => ['required'],
            'user_status_id' => ['required'],
        ]);

        $model = User::find($id);

        $model->first_name = $request->firstname;
        $model->middle_name = $request->middlename;
        $model->last_name = $request->lastname;
        $model->email = $request->email;
        $model->user_status_id = $request->user_status_id;
        $model->user_role_id = $request->user_role_id;
        $model->update();

        return redirect()->route('admin.users.list')->with('success','Record has been successfully updated.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
