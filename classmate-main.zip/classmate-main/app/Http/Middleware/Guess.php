<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class Guess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if($request->session()->exists('professor')) {
            return redirect('/professor/dashboard');
        }

        if($request->session()->exists('student')) {
            return redirect('/student/dashboard');
        }

        if($request->session()->exists('user')) {
            return redirect('/admin/dashboard');
        }

        if($request->session()->exists('parent')) {
            return redirect('/parent/dashboard');
        }

        return $next($request);
    }
}
