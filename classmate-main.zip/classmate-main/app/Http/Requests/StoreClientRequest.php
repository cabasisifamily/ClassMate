<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreClientRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'email' => ['required','unique:clients'],
            'company_name' => ['required', 'max:50'],
            'display_company_name' => ['required', 'max:50'],
            'contact_number' => ['required', 'max:50'],
            'pword' => ['required', 'max:50'],
            'website' => ['max:200'],
            'website_url' => ['required', 'max:200'],
            'contact_person' => ['required', 'max:100'],
        ];
    }

    public function messages() : array {
        return [
            'email.required' => 'The email address is required field',
            'email.unique' => 'The email address is already been taken!!',
            'company_name.required' => 'company name is required',
            'company_name.max' => 'The company name may not be greater than 255 characters.', 
        ];
    }
}
