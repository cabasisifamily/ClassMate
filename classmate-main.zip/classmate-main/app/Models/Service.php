<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Sluggable\SlugOptions;

class Service extends Model
{
    use HasFactory;
    protected $table = "services";
    protected $fillable = ['name','prerequisite','client_id','description','service_status_id'];
}
