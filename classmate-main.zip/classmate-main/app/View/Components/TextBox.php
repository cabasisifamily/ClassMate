<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;
use Carbon\Carbon;

// max="{{ \Carbon\Carbon::now()->format('Y-m-d') }}"
class TextBox extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct(
        public string $label,
        public string $name,
        public string $type="text",
        public string $value="",
        public string $state="",
        public string $id="",
        public bool $readOnly=false,
        public string $placeHolder="",
        public string $min="",
        public string $max="",
    ) {
        if($type == "date") {
            $this->max = Carbon::now()->format('Y-m-d');
        }
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.text-box');
    }
}
