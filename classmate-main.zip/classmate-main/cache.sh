#!/bin/bash

php artisan cache:clear
php artisan route:cache
php artisan config:cache
php artisan storage:link
php artisan serve
