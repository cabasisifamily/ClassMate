<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\CourseStatus;

class CourseStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        CourseStatus::firstOrCreate(['description' => 'Active']);
        CourseStatus::firstOrCreate(['description' => 'Inactive']);
    }
}
