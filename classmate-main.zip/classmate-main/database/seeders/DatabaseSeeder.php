<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call(UserStatusSeeder::class);
        $this->call(UserRoleSeeder::class);
        $this->call(StudentStatusSeeder::class);
        // $this->call(UserSeeder::class);
        $this->call(ProfessorStatusSeeder::class);
        $this->call(SubjectStatusSeeder::class);
        $this->call(ScheduleStatusSeeder::class);
        $this->call(DowSeeder::class);
        $this->call(StudentScheduleStatusSeeder::class);
        $this->call(TimekeepingTypeSeeder::class);
        $this->call(CourseStatusSeeder::class);
        $this->call(SectionStatusSeeder::class);
        $this->call(ParentStatusSeeder::class);
    }
}
