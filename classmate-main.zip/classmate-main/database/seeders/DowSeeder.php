<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Dow;

class DowSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Dow::firstOrCreate([
            'description' => 'Sunday',
            'num' => 1
        ]);
        Dow::firstOrCreate([
            'description' => 'Monday',
            'num' => 2
        ]);
        Dow::firstOrCreate([
            'description' => 'Tuesday',
            'num' => 3
        ]);
        Dow::firstOrCreate([
            'description' => 'Wednesday',
            'num' => 4
        ]);
        Dow::firstOrCreate([
            'description' => 'Thursday',
            'num' => 5
        ]);
        Dow::firstOrCreate([
            'description' => 'Friday',
            'num' => 6
        ]);
        Dow::firstOrCreate([
            'description' => 'Saturday',
            'num' => 7
        ]);
    }
}
