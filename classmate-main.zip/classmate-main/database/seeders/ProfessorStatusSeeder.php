<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\ProfessorStatus;

class ProfessorStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        ProfessorStatus::firstOrCreate(['description' => 'Active']);
        ProfessorStatus::firstOrCreate(['description' => 'Inactive']);
    }
}
