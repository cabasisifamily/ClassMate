<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\ScheduleStatus;

class ScheduleStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        ScheduleStatus::firstOrCreate(['description' => 'Active']);
        ScheduleStatus::firstOrCreate(['description' => 'Inactive']);
    }
}
