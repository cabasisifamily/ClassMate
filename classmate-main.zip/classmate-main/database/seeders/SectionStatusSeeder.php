<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\SectionStatus;

class SectionStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        SectionStatus::firstOrCreate(['description' => 'Active']);
        SectionStatus::firstOrCreate(['description' => 'Inactive']);
    }
}
