<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\StudentScheduleStatus;

class StudentScheduleStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        StudentScheduleStatus::firstOrCreate(['description' => 'Active']);
        StudentScheduleStatus::firstOrCreate(['description' => 'Inactive']);
    }
}
