<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\SubjectStatus;

class SubjectStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        SubjectStatus::firstOrCreate(['description' => 'Active']);
        SubjectStatus::firstOrCreate(['description' => 'Inactive']);
    }
}
