<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\TimekeepingType;

class TimekeepingTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        TimekeepingType::firstOrCreate(['description' => 'Timein']);
        TimekeepingType::firstOrCreate(['description' => 'Timeout']);
        TimekeepingType::firstOrCreate(['description' => 'Late']);
        TimekeepingType::firstOrCreate(['description' => 'Absent']);
    }
}
