#!/bin/sh

echo "updating repository"

git pull origin main

php artisan cache:clear
php artisan route:cache


composer2 install

php artisan migrate --force
php artisan db:seed