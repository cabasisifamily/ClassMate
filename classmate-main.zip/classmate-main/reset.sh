#!/bin/bash

php artisan migrate
php artisan db:seed

php artisan cache:clear
php artisan route:cache

php artisan serve
