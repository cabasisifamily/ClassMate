@extends('layouts.main')
 
@section('title', '- Students')

@section('location')
  <x-page-label label="Dashboard / Admin" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Manage Account">
            
            <x-admin-container>

                <x-option-item 
                    icon="fa-solid fa-user-lock"
                    label="Change Password"
                    description="change your password"
                    link="/admin/changepw"
                />
                
            </x-admin-container>
            
        </x-option-container>

    </x-main-container>
@endsection