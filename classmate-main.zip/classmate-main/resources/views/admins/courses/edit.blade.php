@extends('layouts.main')
 
@section('title', '- Courses')

@section('location')
  <x-page-label label="Dashboard / Courses / Edit" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Edit Course">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/admin/courses/{{$course->id}}/edit">
                @csrf   
                @method('PUT')
                <x-text-box label="Description" value="{{ $course->description }}" placeHolder="Description" name="description"/>
             
                <x-dropdown label="Course Status" name="course_status_id">
                    <x-dropdown-option 
                        label="Active" 
                        value="1"
                        :isSelected="$course->course_status_id == 1 ? 'selected':'' " 
                    />
                    <x-dropdown-option 
                        label="Inactive" 
                        value="2"
                        :isSelected="$course->course_status_id == 2 ? 'selected':'' " 
                    />
                </x-dropdown>

                <x-reg-submit-button 
                    label="Update"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>
@endsection