@extends('layouts.main')
 
@section('title', '- Dashboard')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Dashboard</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Dashboard">
                    
            <x-admin-container>

                <div class="w-full h-full grid grid-cols-1 md:grid-cols-4 gap-4 place-items-center">
                    <div class="w-60 h-32 bg-gray-200 rounded shadow flex items-center flex-col justify-center cursor-pointer">
                        <h1 class="text-xl text-gray-500 font-bold mb-1">Students</h1>
                        <span class="text-xs text-gray-400 mb-2">Total</span>
                        <h2>{{ $data['students'] }}</h2>
                    </div>
                    <div class="w-60 h-32 bg-gray-200 rounded shadow flex items-center flex-col justify-center cursor-pointer">
                        <h1 class="text-xl text-gray-500 font-bold mb-1">Professors</h1>
                        <span class="text-xs text-gray-400 mb-2">Total</span>
                        <h2>{{ $data['professors'] }}</h2>
                    </div>
                    <div class="w-60 h-32 bg-gray-200 rounded shadow flex items-center flex-col justify-center cursor-pointer">
                        <h1 class="text-xl text-gray-500 font-bold mb-1">Courses</h1>
                        <span class="text-xs text-gray-400 mb-2">Total</span>
                        <h2>{{ $data['courses'] }}</h2>
                    </div>
                    <div class="w-60 h-32 bg-gray-200 rounded shadow flex items-center flex-col justify-center cursor-pointer">
                        <h1 class="text-xl text-gray-500 font-bold mb-1">Sections</h1>
                        <span class="text-xs text-gray-400 mb-2">Total</span>
                        <h2>{{ $data['sections'] }}</h2>
                    </div>
                </div>
                
            </x-admin-container>
            
        </x-option-container>
    </x-main-container>
@endsection