@extends('layouts.reg')
 
@section('title', '- Login')


@section('content')
  <div class="flex w-full">

    <div class="hidden md:block w-full bg-gray-200">
      <div class="w-full h-full bg-gray-100 flex items-center justify-center flex-col">
        <img src="{{ asset('images/logo.png') }}" alt="Logo" class="w-72 h-auto">
      </div>
    </div>

    <x-reg-container title="Log in - Administrator">

        @if ($errors->any())
            <div class="mt-5">
            @foreach($errors->all() as $err)
                <p class="text-red-500">{{$err}}</p>
            @endforeach
            </div>
        @endif
    
        @if(Session::has('fail'))
            <div class="mt-5">
                <p class="text-red-500">{{Session::get('fail')}}</p>
            </div>
        @endif

        @if(Session::has('success'))
            <div class="mt-5">
                <p class="text-green-500">{{Session::get('success')}}</p>
            </div>
        @endif

      <form action="/admin/login" method="POST" class="w-full flex flex-col gap-3 mt-10 justify-center items-center">
          @csrf

          <div class="flex w-full items-center justify-center">
            <x-text-box type="email" label="Email" placeHolder="Email" name="email"/>
            <x-text-box type="password" label="Password" placeHolder="Password" name="pword"/>
          </div>

          <x-reg-submit-button 
            label="Login"
          />

      </form>

    </x-reg-container>

    <div class="mb-10"></div>
        
    </div>

  </div>
@endsection