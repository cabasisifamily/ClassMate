@extends('layouts.main')
 
@section('title', '- Parents')

@section('location')
  <x-page-label label="Dashboard / Parents" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Manage Parents">
            
            <x-admin-container>

                <x-option-item 
                    icon="fa-solid fa-list"
                    label="Parents"
                    description="This will list all Parents"
                    link="/admin/parents/list"
                />

                <x-option-item 
                    icon="fa-solid fa-plus"
                    label="Add Parent"
                    description="Add a new Parent here"
                    link="/admin/parents/create"
                />
                
            </x-admin-container>
            
        </x-option-container>

    </x-main-container>
@endsection