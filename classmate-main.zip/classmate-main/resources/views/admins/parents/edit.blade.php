@extends('layouts.main')
 
@section('title', '- Parents')

@section('location')
  <x-page-label label="Dashboard / Parents / Edit" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Edit Parents">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/admin/parents/{{$parent->id}}/edit">
                @csrf
                @method('PUT')
                <input type="hidden" name="id" value="{{$parent->id}}">
                <x-field-container>
                    <x-text-box label="First Name" value="{{ $parent->firstname }}" placeHolder="First Name" name="firstname"/>
                    <x-text-box label="Middle Name" value="{{ $parent->middlename }}" placeHolder="Middle Name" name="middlename"/>
                    <x-text-box label="Last Name" value="{{ $parent->lastname }}" placeHolder="lastname Name" name="lastname"/>
                </x-field-container>

                <x-field-container>
                    <x-contact-textbox 
                        label="Contact No." 
                        value="{{ $parent->contactNo }}" 
                        placeHolder="Contact No" 
                        name="contactNo"
                        :withIcon="true"
                    >
                        <span class="text-gray-600 text-md w-2">+63</span>
                    </x-contact-textbox>

                    <x-text-box label="Email" value="{{ $parent->email }}" placeHolder="Email" name="email"/>
                    
                    <x-dropdown label="Parent Status" name="parent_status_id">
                        <x-dropdown-option 
                            label="Active" 
                            value="1"
                            :isSelected="$parent->parent_status_id == 1 ? 'selected':'' " 
                        />
                        <x-dropdown-option 
                            label="Inactive" 
                            value="2"
                            :isSelected="$parent->parent_status_id == 2 ? 'selected':'' " 
                        />
                    </x-dropdown>
                </x-field-container>

                <x-reg-submit-button 
                    label="Update"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>
@endsection