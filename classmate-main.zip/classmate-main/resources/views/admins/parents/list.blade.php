@extends('layouts.main')
 
@section('title', '- Professors')

@section('location')
  <x-page-label label="Dashboard / Professors / List" />
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Professors">

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif

            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif
            
            <div class="w-full overflow-y-auto md:overflow-y-visible">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>First name</th>
                            <th>Middle name</th>
                            <th>Last name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($parents as $row)
                            <tr class="hover:bg-gray-200">
                                <td>{{ $row->firstname }}</td>
                                <td>{{ $row->middlename }}</td>
                                <td>{{ $row->lastname }}</td>
                                <td>{{ $row->email }}</td>
                                <td>{{ $row->status }}</td>
                                <td class="flex gap-1 flex-col">
                                    @if(Session::get('user')['user_role_id'] == 1)
                                        <x-action-link 
                                            link="/admin/parents/{{$row->id}}/edit" 
                                            type="edit"/>
                                    @endif
                                    <x-action-link 
                                        link="/admin/parents/{{$row->id}}/view" 
                                        type="view"/>
                               </td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>First name</th>
                            <th>Middle name</th>
                            <th>Last name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
        </x-option-container>

    </x-main-container>
@endsection