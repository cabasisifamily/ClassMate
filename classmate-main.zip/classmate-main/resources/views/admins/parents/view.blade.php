@extends('layouts.main')
 
@section('title', '- Dashboard')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Dashboard / Parents / View</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container :label="$parent->id . ' : ' . $parent->lastname . ', ' . $parent->firstname . ' ' . $parent->middlename , ">
        
            <x-container>
                <x-heading title="Personal Information"> 
                
                    <x-information 
                        label="Email"
                        :value="$parent->email"
                    />

                    <x-information 
                        label="Contact Number"
                        :value="'+63' . $parent->contactNo"
                    />

                </x-heading>

                <x-heading title="Student(s)">
                    @foreach ($students as $row)
                        <x-information 
                            label="Name"
                            :value="$row->lastname . ', ' . $row->firstname . ' - ['. strtoupper($row->student_number) .'] ' . '[' .$row->course . ']' "
                        />
                    @endforeach
                </x-heading>

                <x-heading title="Account">
                    <x-information 
                        label="Status"
                        :value="$parent->status"
                    />
                </x-heading>
                
                    
            </x-container>
   
            
        </x-option-container>
    </x-main-container>
@endsection