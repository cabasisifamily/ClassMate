@extends('layouts.main')
 
@section('title', '- Professors')

@section('location')
  <x-page-label label="Dashboard / Professors" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Manage Professors">
            
            <x-admin-container>

                <x-option-item 
                    icon="fa-solid fa-list"
                    label="Professors"
                    description="This will list all Professors"
                    link="/admin/professors/list"
                />

                <x-option-item 
                    icon="fa-solid fa-plus"
                    label="Add Professor"
                    description="Add a new Professor here"
                    link="/admin/professors/create"
                />
                
            </x-admin-container>
            
        </x-option-container>

    </x-main-container>
@endsection