@extends('layouts.main')
 
@section('title', '- Dashboard')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Dashboard / Professor / View</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container :label="$professor->id . ' : ' . $professor->lastname . ', ' . $professor->firstname . ' ' . $professor->middlename , ">
        
            <x-container>
                <x-heading title="Personal Information"> 
                    <x-information 
                        label="Birthday"
                        :value="$professor->birthday"
                    />
                
                    <x-information 
                        label="Email"
                        :value="$professor->email"
                    />

                    <x-information 
                        label="Contact Number"
                        :value="'+63' . $professor->contactNo"
                    />

                </x-heading>

                <x-heading title="Account">
                    <x-information 
                        label="Status"
                        :value="$professor->status"
                    />
                </x-heading>

                <x-heading title="Subjects & Schedules">
                    @foreach ($schedules as $row)
                        <x-information 
                            label="{{$row->subject}}"
                            :value="$row->day . ' (' . $row->stime . ' to ' . $row->etime . ')' . ' = '  . $row->total_minutes . 'minutes' "
                        />
                    @endforeach
                </x-heading>
                
                    
            </x-container>
   
            
        </x-option-container>
    </x-main-container>
@endsection