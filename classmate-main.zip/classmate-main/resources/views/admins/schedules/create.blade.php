@extends('layouts.main')
 
@section('title', '- Services')

@section('location')
  <x-page-label label="Dashboard / Schedules / Create" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Create New Schedule">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/admin/schedules/create">
                @csrf

                <div class="flex w-full items-center justify-center">

                    <x-dropdown label="Section" name="section_id">
                        @foreach($sections as $row)
                            <x-dropdown-option 
                                :label="$row->description" 
                                value="{{$row->id}}"
                            />
                        @endforeach
                    </x-dropdown>

                    <x-dropdown label="Subject" name="subject_id">
                        @foreach($subjects as $row)
                            <x-dropdown-option :label="$row->description" value="{{$row->id}}"/>
                        @endforeach
                    </x-dropdown>

                    <x-dropdown label="Professor" name="professor_id">
                        @foreach($professors as $row)
                            <x-dropdown-option :label="$row->lastname . ', ' . $row->firstname . ' ' . $row->middlename" value="{{$row->id}}"/>
                        @endforeach
                    </x-dropdown>

                </div>

                <div class="flex w-full items-center justify-center">

                    <x-dropdown label="Day" name="dow_id">
                        @foreach($dow as $row)
                            <x-dropdown-option :label="$row->description" value="{{$row->id}}"/>
                        @endforeach
                    </x-dropdown>
                    
                    <x-text-box label="Start" value="{{ old('start_time') }}" placeHolder="Start Time" name="start_time" type="time"/>
                    <x-text-box label="End" value="{{ old('end_time') }}" placeHolder="End Time" name="end_time" type="time"/>
                    
                </div>

                <x-dropdown label="Schedule Status" name="schedule_status_id">
                    <x-dropdown-option label="Active" value="1"/>
                    <x-dropdown-option label="Inactive" value="2"/>
                </x-dropdown>
                
                <hr class="w-full h-1 bg-gray-200">

                <x-reg-submit-button 
                    label="Submit"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>
@endsection