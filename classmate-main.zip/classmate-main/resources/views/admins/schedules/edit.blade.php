@extends('layouts.main')
 
@section('title', '- Services')

@section('location')
  <x-page-label label="Dashboard / Schedules / Edit" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Edit Schedule">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/admin/schedules/{{$schedule->id}}/edit">
                @csrf
                @method('PUT')
                <div class="flex w-full items-center justify-center">

                    <x-dropdown label="Section" name="section_id">
                        @foreach($sections as $row)
                            <x-dropdown-option 
                                :label="$row->description" 
                                value="{{$row->id}}"
                                :isSelected="$schedule->section_id == $row->id ? 'selected':'' " 
                            />
                        @endforeach
                    </x-dropdown>

                    <x-dropdown label="Subject" name="subject_id">
                        @foreach($subjects as $row)
                            <x-dropdown-option 
                                :label="$row->description" 
                                value="{{$row->id}}"
                                :isSelected="$schedule->subject_id == $row->id ? 'selected':'' " 
                            />
                        @endforeach
                    </x-dropdown>

                    <x-dropdown label="Professor" name="professor_id">
                        @foreach($professors as $row)
                            <x-dropdown-option 
                                :label="$row->lastname . ', ' . $row->firstname . ' ' . $row->middlename" 
                                value="{{$row->id}}"
                                :isSelected="$schedule->professor_id == $row->id ? 'selected':'' " 
                            />
                        @endforeach
                    </x-dropdown>

                </div>

                <div class="flex w-full items-center justify-center">

                    <x-dropdown label="Day" name="dow_id">
                        @foreach($dow as $row)
                            <x-dropdown-option 
                                :label="$row->description" 
                                value="{{$row->id}}"
                                :isSelected="$schedule->dow_id == $row->id ? 'selected':'' " 
                            />
                        @endforeach
                    </x-dropdown>
                    
                    <x-text-box label="Start" value="{{ $schedule->start_time }}" placeHolder="Start Time" name="start_time" type="time"/>
                    <x-text-box label="End" value="{{ $schedule->end_time }}" placeHolder="End Time" name="end_time" type="time"/>
                    
                </div>

                <x-dropdown label="Schedule Status" name="schedule_status_id">
                    @foreach($scheduleStatus as $row)
                        <x-dropdown-option 
                            label="{{$row->description}}" 
                            value="{{$row->id}}"
                            :isSelected="$schedule->schedule_status_id == $row->id ? 'selected':'' " 
                        />
                    @endforeach
                </x-dropdown>

                <x-reg-submit-button 
                    label="Submit"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>
@endsection