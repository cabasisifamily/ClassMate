@extends('layouts.main')
 
@section('title', '- Sections')

@section('location')
  <x-page-label label="Dashboard / Sections / Create" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Create New Section">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/admin/sections/create">
                @csrf
                    
                <x-text-box label="Description" value="{{ old('description') }}" placeHolder="Description" name="description"/>
             
                <x-dropdown label="Course Status" name="section_status_id">
                    <x-dropdown-option label="Active" value="1"/>
                    <x-dropdown-option label="Inactive" value="2"/>
                </x-dropdown>

                <x-reg-submit-button 
                    label="Submit"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>
@endsection