@extends('layouts.main')
 
@section('title', '- Sections')

@section('location')
  <x-page-label label="Dashboard / Sections / List" />
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Sections">

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif

            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif
            
            <div class="w-full">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Status</th>
                            @if(Session::get('user')['user_role_id'] == 1)
                                <th>Action</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($sections as $row)
                            <tr class="hover:bg-gray-200">
                                <td>{{ $row->description }}</td>
                                <td>{{ $row->status }}</td>
                                @if(Session::get('user')['user_role_id'] == 1)
                                    <td class="flex gap-1 flex-col">
                                        <x-action-link 
                                            link="/admin/sections/{{$row->id}}/edit" 
                                            type="edit"/>
                                    </td>
                                @endif
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Description</th>
                            <th>Status</th>
                            @if(Session::get('user')['user_role_id'] == 1)
                                <th>Action</th>
                            @endif
                        </tr>
                    </tfoot>
                </table>
            </div>
            
        </x-option-container>

    </x-main-container>
@endsection