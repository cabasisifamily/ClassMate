@extends('layouts.main')
 
@section('title', '- Students')

@section('location')
  <x-page-label label="Dashboard / Students" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Manage Students">
            
            <x-admin-container>

                <x-option-item 
                    icon="fa-solid fa-list"
                    label="Students"
                    description="This will list all Students"
                    link="/admin/students/list"
                />

                <x-option-item 
                    icon="fa-solid fa-plus"
                    label="Add Student"
                    description="Add a new Professor here"
                    link="/admin/students/create"
                />
                
            </x-admin-container>
            
        </x-option-container>

    </x-main-container>
@endsection