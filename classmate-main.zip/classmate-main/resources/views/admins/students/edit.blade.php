@extends('layouts.main')
 
@section('title', '- Services')

@section('location')
  <x-page-label label="Dashboard / Student / Edit" />
@endsection

@section('modal')
<div class="w-full h-full bg-gray-300 fixed z-50 bg-opacity-50 hidden flex-col items-center justify-center" id="rf-modal">
    <div class="h-32 w-52 bg-white rounded-lg p-2 shadow-lg">
       <div class="text-center">
           <input type="text" class="w-0 opacity-0" id="rfid">
            <div class="flex flex-col items-center justify-center w-full h-full gap-1">
                <img src="{{ asset('images/rfid.png') }}" alt="" class="w-8 h-auto">
                <h4 class="font-bold tracking-wide text-gray-700">Please tap the RFID</h4>
                <span class="text-xs text-gray-500">Waiting for card...</span>
            </div>
       </div>
    </div>
</div>
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Edit Student">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/admin/students/{{$student->id}}/edit">
                @csrf
                @method('PUT')

                <x-field-container>

                    <x-dropdown label="Select Course" name="course_id">
                        @foreach ($courses as $row)
                            <x-dropdown-option 
                                label="{{$row->description}}" 
                                value="{{$row->id}}"
                                :isSelected="$student->course_id == $row->id ? 'selected':'' " 
                            />
                        @endforeach
                    </x-dropdown>

                    <x-text-box label="Student Number" value="{{ $student->student_number }}" placeHolder="Student Number" name="student_number"/>

                </x-field-container>

                <x-field-container>
                    <x-text-box label="First Name" value="{{ $student->firstname }}" placeHolder="Service Name" name="firstname"/>
                    <x-text-box label="Middle Name" value="{{ $student->middlename}}" placeHolder="Middle Name" name="middlename"/>
                    <x-text-box label="Last Name" value="{{ $student->lastname }}" placeHolder="Middle Name" name="lastname"/>
                </x-field-container>

                <x-field-container>
                    <x-text-box label="Email" value="{{ $student->email }}" placeHolder="Service Name" name="email" type="email"/>
                   
                    <x-text-box label="Birthday" value="{{ $student->birthday }}" placeHolder="Birthday" name="birthday" type="date"/>

                    <x-dropdown label="Student Status" name="student_status_id">
                        
                        <x-dropdown-option 
                            label="Active" 
                            :isSelected="$student->student_status_id == 1 ? 'selected':'' " 
                            value="1"/>

                        <x-dropdown-option 
                            label="Inactive" 
                            :isSelected="$student->student_status_id == 2 ? 'selected':'' "   
                            value="2"/>
                            
                    </x-dropdown>
                </x-field-container>

                <x-text-area 
                    label="Address"
                    name="address"
                    value="{{ $student->address }}"
                />

                <x-field-container>

                    <x-contact-textbox 
                        label="Contact No." 
                        value="{{ $student->contactNo  }}" 
                        placeHolder="Contact No" 
                        name="contactNo"
                        :withIcon="true"
                    >
                        <span class="text-gray-600 text-md w-2">+63</span>
                    </x-contact-textbox>
                   
                    <x-text-box label="Contact Person" value="{{ $student->contactPerson }}" placeHolder="Contact Person" name="contactPerson"/>

                    <div class="flex justify-center items-center w-full h-full">
                        <x-rfid-text 
                            placeHolder="Tap your RFID" 
                            id="rfid-holder"
                            name="rfid"
                            value="{{ $student->rfid }}"
                            buttonId="rf-button"  
                        />
                    </div>
                   
                </x-field-container>

                <x-field-container>
                    <x-text-box type="file" label="Upload Picture" value="{{ old('contactPerson') }}" placeHolder="Upload Picture" name="picture" id="picture"/>
                </x-field-container>

                <div class="flex justify-start w-full">
                    <img src="{{ asset('storage/' . $student->picture) }}" id="uploaded-picture" class="float-left h-32 w-32 object-cover rounded-full border">
                </div>
                    
                <x-reg-submit-button 
                    label="Submit"
                    id="submit"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>

@section('js')
<script>
    $(document).ready(function() {

        let sidebar = $("#right-sidebar");
        $("#btn-burger").on('click',function() {
            sidebar.toggleClass('hidden');

            if($("#btn-icon").hasClass('fa-solid fa-bars')) {
                $("#btn-icon").removeClass("fa-solid fa-bars");
                $("#btn-icon").addClass("fa-solid fa-xmark");
            } else {
                $("#btn-icon").removeClass("fa-solid fa-xmark");
                $("#btn-icon").addClass("fa-solid fa-bars");
            }
        });


        $('#rf-modal').click(function() {
            console.log(`clicked`)
            $(this).addClass("hidden");
            $(this).removeClass("flex");
        })

        $('#rf-button').click(function() {
            $("#rfid-holder").val('');
            $("#rfid").val('');
            $('#rf-modal').removeClass("hidden");
            $('#rf-modal').addClass("flex");
            $("#rfid").focus();
        });

        $("#rfid").keyup(function() {
            let value = $(this).val();
            console.log(`value outside:`,value);
            if(value.length >= 10) {
                console.log(`value inside:`,value);
                $("#rfid-holder").val('');
                $("#rfid-holder").val($(this).val());
                $('#rf-modal').removeClass("flex");
                $('#rf-modal').addClass("hidden");
                $("#rfid").val('');
            }
        });

        $('#picture').on('change', function(event) {
            var file = event.target.files[0]; // Get the selected file

            // Check if the file is an image
            if (file && file.type.match('image.*')) {
                var reader = new FileReader(); // Create a new FileReader object

                // Read the image file as a data URL
                reader.onload = function(e) {
                    // Set the source of the image element to the data URL
                    $('#uploaded-picture').attr('src', e.target.result);
                };

                // Read the image file
                reader.readAsDataURL(file);
            } else {
                // If the selected file is not an image, display an error message
                alert('Please select a valid image file.');
                // Clear the file input field
                $('#picture').val('');
                // Reset the image source
                $('#uploaded-picture').attr('src', '#');
            }
        });
    });
</script>
@endsection

@endsection