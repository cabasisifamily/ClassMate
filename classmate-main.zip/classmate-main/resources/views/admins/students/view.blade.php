@extends('layouts.main')
 
@section('title', '- Dashboard')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Dashboard / Students / View</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container :label="strtoupper($student->student_number) . ' : ' . strtoupper($student->lastname . ', ' . $student->firstname . ' ' . $student->middlename) , ">
        
            <x-container>
                <x-heading title="Personal Information"> 
                    <div class="flex-row md:flex justify-between items-center gap-2">
                        <div class="flex-1 mb-4 md:mb-0">
                            <x-information 
                                label="Birthday"
                                :value="$student->birthday"
                            />
                        
                            <x-information 
                                label="Email"
                                :value="$student->email"
                            />

                            <x-information 
                                label="Contact Number"
                                :value="'+63' . $student->contactNo"
                            />

                            <x-information 
                                label="Emergency Contact Person"
                                :value="$student->contactPerson"
                            />

                            <x-information 
                                label="Address"
                                :value="$student->address"
                            />
                        </div>

                        <div class="flex-none">
                            <img src="{{ asset('storage/' . $student->picture) }}" class="rounded-full object-cover w-32 h-32">
                        </div>

                    </div>
                </x-heading>

                <x-heading title="Guardian(s)" :actionButton="true" actionButtonLabel="Add New" actionButtonId="add-guardian"> 
                    @if($guardian->isEmpty())
                        <p class="text-sm text-center">No available guardian</p>
                    @endif
                    <div id="parents">
                        @foreach ($guardian as $row)
                            <x-information 
                                label="Name"
                                :value="strtoupper($row->lastname . ', ' . $row->firstname . ' ' . $row->middlename)"
                                :actionButton="true"
                                actionButtonLabel="Remove"
                                actionButtonId="btn-remove"
                                actionButtonClass="btn-remove"
                                :dataValue="$row->ps_id"
                                type="danger"
                            />
                        @endforeach
                    </div>
                </x-heading>

                <x-heading title="Account">
                    <x-information 
                        label="Course"
                        :value="$student->course"
                    />
                    <x-information 
                        label="Status"
                        :value="$student->status"
                    />
                </x-heading>

                <x-heading title="Subjects & Schedules">
                    @foreach($schedules as $row)
                        <x-information 
                            label="{{$row->subject}}"
                            :value="$row->day . ', ' .$row->stime . ' to ' . $row->etime . ', ' . $row->total_minutes.'minutes' . ' - (' . $row->professor . ')' "
                        />
                    @endforeach
                </x-heading>
                
                    
            </x-container>
   
            
        </x-option-container>
    </x-main-container>
@endsection

@section('modal')
<x-modal-container id="modal" additionalClass="hidden">
    <div class="mb-3 flex justify-end items-center">
        <button class="py-1 px-2 text-xl" id="btn-close">
            <i class="fa-solid fa-xmark text-xl"></i>
        </button>
    </div>
    <div class="w-full overflow-x-auto">
        <table id="example" class="w-full" style="width:100%">
            <thead class="w-full">
                <tr class="w-full">
                    <th>First name</th>
                    <th>Middle name</th>
                    <th>Last name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody class="w-full" id="table-body">
                @foreach ($parents as $row)
                    <tr class="hover:bg-gray-200">
                        <td>{{$row->firstname}}</td>
                        <td>{{$row->middlename}}</td>
                        <td>{{$row->lastname}}</td>
                        <td>{{$row->email}}</td>
                        <td class="flex gap-1 flex-col">
                            <button class="bg-black py-1 px-2 text-white rounded font-bold btn-add" data-id="{{$row->id}}">Add</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>First name</th>
                    <th>Middle name</th>
                    <th>Last name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
    </div>
</x-modal-container>
@endsection


@section('js')
    <script>
        $(document).ready(function() {
            let sidebar = $("#right-sidebar");
            $("#btn-burger").on('click',function() {
                sidebar.toggleClass('hidden');

                if($("#btn-icon").hasClass('fa-solid fa-bars')) {
                    $("#btn-icon").removeClass("fa-solid fa-bars");
                    $("#btn-icon").addClass("fa-solid fa-xmark");
                } else {
                    $("#btn-icon").removeClass("fa-solid fa-xmark");
                    $("#btn-icon").addClass("fa-solid fa-bars");
                }
            });

            $("#add-guardian").click(function() {
                $("#modal").removeClass("hidden");
            });

            $("#btn-close").click(function() {
                $("#modal").addClass("hidden");
            });

            $("#table-body").on("click", ".btn-add", function() {
                let pid = $(this).data("id");
                
                if(confirm("Are you sure you want to add this Guardian?")) {
                    const postData = {
                        student_id: {{$student->id}},
                        parent_id: pid,
                        _token: '{{ csrf_token() }}',
                    };
                    $.post(`/admin/students/parents/add`, postData, function(data) {
                        console.log(data)
                        if(data.success) {
                            alert("Guardian has been successfully added");
                            $("#modal").addClass("hidden");
                            location.reload();
                        } else {
                            alert("Duplicate entry, guardian already exists.")
                        }
                    });
                }

            });

            $("#parents").on("click", ".btn-remove", function() {
                let psId = $(this).data("value");

                const postData = {
                    id:psId,
                    _token: '{{ csrf_token() }}',
                };

                if(confirm("Are you sure you want to add this Guardian?")) {
                    $.post(`/admin/students/parents/delete`, postData, function(data) {
                        console.log(data)
                        if(data.success) {
                            alert("Guardian has been successfully deleted");
                            location.reload();
                        }
                    });
                }

            });

        });
    </script>
@endsection