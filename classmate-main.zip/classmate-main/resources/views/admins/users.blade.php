@extends('layouts.main')
 
@section('title', '- User')

@section('location')
  <x-page-label label="Dashboard / Users" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Manage Users">
            
            <x-admin-container>

                <x-option-item 
                    icon="fa-solid fa-list"
                    label="Users"
                    description="This will list all Students"
                    link="/admin/users/list"
                />

                <x-option-item 
                    icon="fa-solid fa-plus"
                    label="Add User"
                    description="Add a new Professor here"
                    link="/admin/users/create"
                />
                
            </x-admin-container>
            
        </x-option-container>

    </x-main-container>
@endsection