@extends('layouts.main')
 
@section('title', '- Services')

@section('location')
  <x-page-label label="Dashboard / User / Edit" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Edit User">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/admin/users/{{$user->id}}/edit">
                @csrf
                @method('PUT')
                <input type="hidden" name="id" value="{{$user->id}}">
                <x-field-container>
                    <x-text-box label="First Name" value="{{ $user->first_name }}" placeHolder="First Name" name="firstname"/>
                    <x-text-box label="Middle Name" value="{{ $user->middle_name }}" placeHolder="Middle Name" name="middlename"/>
                    <x-text-box label="Last Name" value="{{ $user->last_name }}" placeHolder="Middle Name" name="lastname"/>
                </x-field-container>

                <x-field-container>
                    <x-text-box label="Email" value="{{ $user->email }}" placeHolder="Email" name="email" type="email"/>
                   
                    <x-dropdown label="User role" name="user_role_id">
                        <x-dropdown-option 
                            label="Admin" 
                            value="1"
                            :isSelected="$user->user_role_id == 1 ? 'selected':'' " 
                        />
                        <x-dropdown-option 
                            label="User" 
                            value="2"
                            :isSelected="$user->user_role_id == 2 ? 'selected':'' " 
                        />
                    </x-dropdown>

                    <x-dropdown label="User Status" name="user_status_id">
                        <x-dropdown-option 
                            label="Active" 
                            value="1"
                            :isSelected="$user->user_status_id == 1 ? 'selected':'' " 
                        />
                        <x-dropdown-option 
                            label="Inactive" 
                            value="2"
                            :isSelected="$user->user_role_id == 2 ? 'selected':'' " 
                        />
                    </x-dropdown>

                </x-field-container>

                <x-reg-submit-button 
                    label="Update"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>
@endsection