@extends('layouts.main')
 
@section('title', '- Utilities')

@section('location')
  <x-page-label label="Dashboard / Utilities" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Manage Utilities">
            
            <x-admin-container>

                <div class="grid grid-cols-2 gap-x-1 gap-y-2 md:gap-x-10 md:gap-y-5">
                    <x-option-item 
                        icon="fa-solid fa-file-circle-check"
                        label="Subjects"
                        description="This will list all Subjects"
                        link="/admin/subjects/list"
                    />

                    <x-option-item 
                        icon="fa-solid fa-plus"
                        label="Add Subjects"
                        description="Add a new Subject here"
                        link="/admin/subjects/create"
                    />
                    
                    <x-option-item 
                        icon="fa-solid fa-hourglass-half"
                        label="Schedules"
                        description="This will list all Schedules"
                        link="/admin/schedules/list"
                    />

                    <x-option-item 
                        icon="fa-solid fa-plus"
                        label="Add Schedule"
                        description="Add a new Schedule here"
                        link="/admin/schedules/create"
                    />

                    <x-option-item 
                        icon="fa-solid fa-children"
                        label="Courses"
                        description="This will list all Courses"
                        link="/admin/courses/list"
                    />

                    <x-option-item 
                        icon="fa-solid fa-plus"
                        label="Add Course"
                        description="Add a new Course here"
                        link="/admin/courses/create"
                    />

                    <x-option-item 
                        icon="fa-solid fa-clipboard"
                        label="Section"
                        description="This will list all Section"
                        link="/admin/sections/list"
                    />

                    <x-option-item 
                        icon="fa-solid fa-plus"
                        label="Add Section"
                        description="Add a new Section here"
                        link="/admin/sections/create"
                    />

                </div>
                
            </x-admin-container>
            
        </x-option-container>

    </x-main-container>
@endsection