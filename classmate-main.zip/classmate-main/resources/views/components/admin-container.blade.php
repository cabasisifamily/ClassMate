<div class="flex flex-col md:flex-row md:justify-start items-start md:items-center gap-3 md:gap-10 mt-5 md:mt-5">
    {{$slot}}
</div>