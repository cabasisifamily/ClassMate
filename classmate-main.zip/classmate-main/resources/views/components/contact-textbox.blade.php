@props([
    'label' => '',
    'placeHolder' => '',
    'name' => '',
    'value' => '',
    'readOnly' => false,
    'id' => '',
    'withIcon' => false,
])
<div class="flex gap-2 flex-col w-full items-center justify-center px-1">
    <label class="text-gray-600 w-full">{{$label}}</label>

    <div class="flex items-center justify-start border border-gray-300 w-full rounded group bg-gray-100 hover:bg-white">

        @if($withIcon)
            <div class="h-full ms-1 px-1 group-hover:bg-white group-active:bg-white bg-gray-100">
                {{$slot}}
            </div>
        @endif

        <input 
            type="text" 
            placeholder="{{$placeHolder}}" 
            name="{{$name}}"
            value="{{$value}}"
            {{$readOnly ? 'readonly':''}}
            id="{{$id}}"
            class="bg-gray-100 h-10 ps-1 pe-0 md:pe-5 outline-none group-hover:bg-white group-active:bg-white w-full"
        />
    </div>

</div>