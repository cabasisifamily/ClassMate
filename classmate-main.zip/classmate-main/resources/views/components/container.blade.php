<div class="mt-5 md:mt-5">
    {{$slot}}
</div>