@props(['label'=>'','value'=>'','isSelected'=>''])

<option value="{{$value}}" {{$isSelected}}>{{$label}}</option>