<div class="flex flex-col md:flex-row w-full items-center justify-center gap-2 md:gap-0">
    {{$slot}}
</div>