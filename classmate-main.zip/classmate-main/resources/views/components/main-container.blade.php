<div class="w-full h-full px-1 md:px-10 relative">
    {{$slot}}
</div>