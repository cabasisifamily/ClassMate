<div class="w-full h-12 bg-gray-100 flex items-center">
    <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">{{$label}}</h4>
</div>