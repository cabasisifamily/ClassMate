
@props(['location' => '','label' => 'PDF Report','type' => 'pdf'])

<a href="{{$location}}" class="flex items-center gap-1 group" target="_blank">
    @if($type == "pdf")
        <i class="fa-solid fa-file-pdf text-red-500 group-hover:text-red-400"></i>
        <h4 class="text-red-500 font-semibold group-hover:text-red-400">{{$label}}</h4>
    @elseif($type == "spreadsheet")
        <i class="fa-solid fa-table text-green-600 group-hover:text-red-400"></i>
        <h4 class="text-green-600 font-semibold group-hover:text-red-400">{{$label}}</h4>
    @endif
</a>