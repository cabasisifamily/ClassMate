@props([
    'id'=>'',
    'placeHolder'=>'',
    'value'=>'',
    'label'=>'RFID',
    'name'=>'rfid',
    'buttonId' => '',
])

<div class="flex gap-2 flex-col w-full items-center justify-center px-1">
    <label class="text-gray-600 w-full">{{$label}}</label>
    <div class="flex items-center gap-1 w-full">
        <input
            id={{$id}} 
            type="text" 
            placeholder="{{$placeHolder}}" 
            name="{{$name}}"
            value="{{$value}}"
            readonly
            class="border w-full rounded h-9 px-5 outline-none bg-gray-100 hover:bg-white active:bg-white"/>

        <div class="w-24 h-full bg-black flex items-center justify-center py-1 rounded-lg cursor-pointer" id="{{$buttonId}}">
            <span class="text-white font-bold">Tap</span>
        </div>
    </div>
</div>