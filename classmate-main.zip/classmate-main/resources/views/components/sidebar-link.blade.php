<li class="p-1 flex items-center gap-2 hover:bg-gray-200 hover:rounded ">
    <div>
        <i class="{{$icon}} text-gray-600 text-xs md:text-lg"></i>         
    </div>
    <a href="{{$link}}" class="font-semibold text-xs md:text-lg text-gray-700">{{$label}}</a>
</li>