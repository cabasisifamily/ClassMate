
<td class="border-b border-slate-300 p-0 py-2 px-1 text-xs md:text-[14px] md:py-3 md:px-0">{{$slot}}</td>