@props(['label'=>''])

<th class="border-b border-slate-300 bg-gray-100 p-0 py-2 text-sm md:text-md md:py-3 md:px-1">{{$label}}</th>