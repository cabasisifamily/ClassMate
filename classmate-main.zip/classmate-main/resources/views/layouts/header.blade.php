<header class="bg-black w-full h-16">
    <div class="flex justify-between items-center text-white h-full w-full">
        <div class="ms-5">
            <a href="/admin/dashboard" class="flex items-center gap-1 justify-center">
                <img src="{{ asset('images/logo-icon.png') }}" alt="" class="w-16">
                <h1 class="font-bold tracking-wide text-gray-200">ClassMate</h1>
            </a>
        </div>

        
       <div>

            <div class="me-5 text-xl block md:hidden cursor-pointer" id="btn-burger">
                <i id="btn-icon" class="fa-solid fa-bars"></i>
            </div>
            
            <div class="flex items-center gap-4">
                @if(Session::has('user'))
                    <h2 class="hidden md:block">Hi {{Session::get('user')['user_role_id'] == 1 ? "Admin":"User"}} {{ ucfirst(Session::get('user')['first_name'])}}</h2>
                @elseif (Session::has('professor'))
                    <h2 class="hidden md:block">Hi Prof. {{ ucfirst(Session::get('professor')['firstname'])}}</h2>
                @elseif (Session::has('parent'))
                    <h2 class="hidden md:block">Hi {{ ucfirst(Session::get('parent')['firstname'])}}</h2>
                @else
                    <h2 class="hidden md:block">Hi Student {{ ucfirst(Session::get('student')['firstname'])}}</h2>
                @endif
                
                <div class="hidden md:block">|</div>

                <div class="me-5 hidden md:block group">
                    @if(Session::has('user'))
                        <form class="flex items-center gap-1" action="/admin/logout" method="POST">
                    @elseif (Session::has('professor'))
                        <form class="flex items-center gap-1" action="/professor/logout" method="POST">
                    @elseif (Session::has('parent'))
                        <form class="flex items-center gap-1" action="/parent/logout" method="POST">
                    @else
                        <form class="flex items-center gap-1" action="/student/logout" method="POST">
                    @endif
                            @csrf
                            <button type="submit" class="text-sm tracking-wide text-gray-200 group-hover:text-gray-500 flex items-center gap-1 self-center">
                                <i class="fa-solid fa-right-from-bracket group-hover:text-gray-500"></i>
                                <span>Logout</span>
                            </button>
                        </form>
                </div>
                
            </div>
            
       </div>
    </div>
</header>


<div class="h-screen w-full bg-black bg-opacity-25 absolute z-10 hidden md:hidden" id="right-sidebar">
    <div class="bg-white w-1/3 h-screen float-right">
        @include('partials.navs')
    </div>
</div>

@section('js')
    <script>
        $(document).ready(function() {
            let sidebar = $("#right-sidebar");
            $("#btn-burger").on('click',function() {
                sidebar.toggleClass('hidden');

                if($("#btn-icon").hasClass('fa-solid fa-bars')) {
                    $("#btn-icon").removeClass("fa-solid fa-bars");
                    $("#btn-icon").addClass("fa-solid fa-xmark");
                } else {
                    $("#btn-icon").removeClass("fa-solid fa-xmark");
                    $("#btn-icon").addClass("fa-solid fa-bars");
                }
            });
        });
    </script>
@endsection
