<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/x-icon" href="{{ asset('images/logo-icon.png') }}">
  <title>ClassMate @yield('title')</title>
  <link rel="stylesheet" href="{{ asset('fontawesome-free-6.4.2/css/all.min.css') }}">
  @vite('resources/css/app.css')
  <!-- <link rel="stylesheet" href="{{ asset('build/assets/app-8e25826b.css') }}"> -->
</head>
<body>
      @yield('modal')
      
      @include('layouts.header')

      @yield('location')

      <div class="w-[150px] h-full absolute hidden md:block">
          <div class="ms-3">
              @include('partials.navs')
          </div>
      </div>

      <div class="flex items-center gap-5 mt-10">
        <div class="w-full h-full ml-0 md:ml-48">
            @yield('content')
        </div>
      </div>


      <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
      <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.13.6/js/dataTables.tailwindcss.min.js"></script>
      <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
      <script src="https://cdn.tailwindcss.com"></script>
      <script>	
        new DataTable('#example');
      </script>

      @yield('js')
      {{-- @include('layouts.footer') --}}
      
</body>
</html>