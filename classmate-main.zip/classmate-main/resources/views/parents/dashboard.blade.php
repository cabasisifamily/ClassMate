@extends('layouts.main')
 
@section('title', '- Dashboard')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Dashboard</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Dashboard">
                    
            <x-admin-container>

                <x-option-item 
                    icon="fa-solid fa-bell"
                    label="Notifications"
                    description="View your notifications"
                    link="/parent/notifications"
                    :notification="$notif > 0 ? true : false"
                    :notificationValue="$notif"
                />

               <x-option-item 
                    icon="fa-solid fa-user-tie"
                    label="Students"
                    description="View your student(s)"
                    link="/parent/students"
                />

            </x-admin-container>
            
        </x-option-container>
    </x-main-container>
@endsection