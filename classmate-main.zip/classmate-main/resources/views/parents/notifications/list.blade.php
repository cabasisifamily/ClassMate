@extends('layouts.main')
 
@section('title', '- Notifications')

@section('location')
  <x-page-label label="Dashboard / Notifications / List" />
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Notifications">

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif

            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif
            
            <div class="w-full overflow-y-auto md:overflow-y-visible">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Schedules</th>
                            <th>Descriptions</th>
                            <th>Status</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                        @foreach ($notifications as $row)
                            <tr class="hover:bg-gray-200 {{$row->is_read == 0 ? 'font-bold text-blue-500':'text-black'}} cursor-pointer onclick-table" data-location="/parent/notifications/{{$row->id}}">
                                <td class="flex items-center gap-1">
                                    <i class="fa-solid {{$row->is_read == 0 ? 'fa-envelope':'fa-envelope-open-text'}}"></i>
                                </td>
                                <td>{{$row->date}}</td>
                                <td>{{$row->student}}</td>
                                <td>{{ $row->subject }} - ({{$row->stime }} - {{$row->etime}})</td>
                                <td>{{ $row->description }}</td>
                                @if(str_contains(strtolower($row->description),'late'))
                                    <td class="flex items-center gap-1">
                                        <span>Late</span>
                                        <i class="fa-solid fa-flag text-yellow-500"></i>
                                    </td>
                                @elseif(str_contains(strtolower($row->description),'absent'))
                                    <td class="flex items-center gap-1">
                                        <span>Absent</span>
                                        <i class="fa-solid fa-flag text-red-500"></i>
                                    </td>
                                @elseif(str_contains(strtolower($row->description),'time out'))
                                    <td>Time Out</td>
                                @elseif(str_contains(strtolower($row->description),'on time'))
                                    <td>Present</td>
                                @else
                                    <td>{{ $row->status }}</td>
                                @endif
                                <td>{{$row->tstamp}}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Schedules</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Timestamp</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
        </x-option-container>

    </x-main-container>
@endsection


@section('js')
    <script>
        $(document).ready(function() {
            let sidebar = $("#right-sidebar");
            $("#btn-burger").on('click',function() {
                sidebar.toggleClass('hidden');

                if($("#btn-icon").hasClass('fa-solid fa-bars')) {
                    $("#btn-icon").removeClass("fa-solid fa-bars");
                    $("#btn-icon").addClass("fa-solid fa-xmark");
                } else {
                    $("#btn-icon").removeClass("fa-solid fa-xmark");
                    $("#btn-icon").addClass("fa-solid fa-bars");
                }
            });

            $("#table-body").on("click", ".onclick-table", function() {
                let location = $(this).data("location");
                window.location.href = location;
            });
        });
    </script>
@endsection