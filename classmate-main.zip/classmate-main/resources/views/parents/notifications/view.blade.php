@extends('layouts.main')
 
@section('title', '- Schedule')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Professor / Schedule / View</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="{{$notification->subject}} - {{$notification->date}}">
            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
        
            <x-container>
                <x-heading title="Information" :button="true" buttonLabel="Go Back" location="/parent/notifications">

                    <x-information 
                        label="Student"
                        value="{{$notification->student}}"
                    />
                    
                    <x-information 
                        label="Professor"
                        value="{{$notification->professor}}"
                    />

                    <x-information 
                        label="Day"
                        value="{{$notification->day}}"
                    />

                    <x-information 
                        label="Time"
                        value="{{$notification->stime}} - {{$notification->etime}}"
                    />
            

                </x-heading>


                <x-heading title="Description">
                    
                    <x-information 
                        label="Remarks"
                        value="{{$notification->description}}"
                    />
                    
                    <x-information 
                        label="Time in / Time Out / Timestamp"
                        value="{{$notification->tstamp}}"
                    />

                </x-heading>

                
                    
            </x-container>
   
            
        </x-option-container>
    </x-main-container>
@endsection