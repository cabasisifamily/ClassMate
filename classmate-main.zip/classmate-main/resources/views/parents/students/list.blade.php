@extends('layouts.main')
 
@section('title', '- Parents')

@section('location')
  <x-page-label label="Dashboard / Students / List" />
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Students">

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif

            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif
        
            <div class="w-full">
                <table id="example" class="display w-full" style="width:100%">
                    <thead class="w-full">
                        <tr class="w-full">
                            <th>Student No.</th>
                            <th>First name</th>
                            <th>Middle name</th>
                            <th>Last name</th>
                            <th>Course</th>
                            <th>Email</th>
                            <th>Birthday</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="w-full">
                        @foreach ($students as $row)
                            <tr class="hover:bg-gray-200">
                               <td>{{$row->student_number}}</td>
                               <td>{{$row->firstname}}</td>
                               <td>{{$row->middlename}}</td>
                               <td>{{$row->lastname}}</td>
                               <td>{{$row->course}}</td>
                               <td>{{$row->email}}</td>
                               <td>{{$row->birthday}}</td>
                               <td>{{$row->status}}</td>
                               <td class="flex gap-1 flex-col">
                                    <x-action-link 
                                        link="/parent/students/{{$row->id}}/view" 
                                        type="view"/>
                               </td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Student No.</th>
                            <th>First name</th>
                            <th>Middle name</th>
                            <th>Last name</th>
                            <th>Course</th>
                            <th>Email</th>
                            <th>Birthday</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
        </x-option-container>

    </x-main-container>
@endsection