@extends('layouts.main')
 
@section('title', '- Dashboard')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Dashboard / Students / View</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container :label="strtoupper($student->student_number) . ' : ' . strtoupper($student->lastname . ', ' . $student->firstname . ' ' . $student->middlename) , ">
        
            <x-container>
                <x-heading title="Personal Information"> 
                    <div class="flex-row md:flex justify-between items-center gap-2">
                        <div class="flex-1 mb-4 md:mb-0">
                            <x-information 
                                label="Birthday"
                                :value="$student->birthday"
                            />
                        
                            <x-information 
                                label="Email"
                                :value="$student->email"
                            />

                            <x-information 
                                label="Contact Number"
                                :value="'+63' . $student->contactNo"
                            />

                            <x-information 
                                label="Emergency Contact Person"
                                :value="$student->contactPerson"
                            />

                            <x-information 
                                label="Address"
                                :value="$student->address"
                            />
                        </div>

                        <div class="flex-none">
                            <img src="{{ asset('storage/' . $student->picture) }}" class="rounded-full object-cover w-32 h-32">
                        </div>

                    </div>
                </x-heading>

                <x-heading title="Account">
                    <x-information 
                        label="Course"
                        :value="$student->course"
                    />
                    <x-information 
                        label="Status"
                        :value="$student->status"
                    />
                </x-heading>

                <x-heading title="Subjects & Schedules">
                    @foreach($schedules as $row)
                        <x-information 
                            label="{{$row->subject}}"
                            :value="$row->day . ', ' .$row->stime . ' to ' . $row->etime . ', ' . $row->total_minutes.'minutes' . ' - (' . $row->professor . ')' "
                        />
                    @endforeach
                </x-heading>
                
                    
            </x-container>
   
            
        </x-option-container>
    </x-main-container>
@endsection

