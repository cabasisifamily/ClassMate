<div class="hidden md:block w-full bg-cover bg-opacity-25 bg-no-repeat" style="background-image: url('{{ asset('images/login-back.png') }}')">
    <div class="w-full h-full flex items-center justify-center flex-col">
        <img src="{{ asset('images/logo.png') }}" alt="Logo" class="w-82 h-auto">
        
        <div class="mt-5">
            <h1 class="text-center text-2xl text-blue-500 font-bold">Web Base Attendance System</h1>
            <p class="text-center text-gray-400 text-sm">Seamless Attendance Management Online</p>
        </div>

    </div>
</div>