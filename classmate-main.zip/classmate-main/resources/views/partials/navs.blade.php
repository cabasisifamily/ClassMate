<ul class="mt-10 flex flex-col gap-3 items-start ms-4 md:ms-0">

    @if(Session::has('user'))
        <x-sidebar-link 
          label='Dashboard'
          icon="fa-solid fa-chart-line"
          link="/admin/dashboard" 
        />

        <x-sidebar-link 
          label='Students'
          icon="fa-solid fa-graduation-cap"
          link="/admin/students" 
        />

        <x-sidebar-link 
          label='Professors'
          icon="fa-solid fa-person-chalkboard"
          link="/admin/professors" 
        />

        <x-sidebar-link 
          label='Parents'
          icon="fa-solid fa-people-line"
          link="/admin/parents" 
        />

        <x-sidebar-link 
          label='Utilities'
          icon="fa-solid fa-gears"
          link="/admin/utilities" 
        />
        
        @if(Session::get('user')['user_role_id'] == 1)
          <x-sidebar-link 
            label='Users'
            icon="fa-solid fa-users"
            link="/admin/users" 
          />
        @endif

        <x-sidebar-link 
          label='Account'
          icon="fa-solid fa-user-tie"
          link="/admin/account" 
        />
    @elseif (Session::has('professor'))
        <x-sidebar-link 
          label='Dashboard'
          icon="fa-solid fa-chart-line"
          link="/professor/dashboard" 
        />
        <x-sidebar-link 
          label='Schedules'
          icon="fa-solid fa-hourglass-half"
          link="/professor/schedules" 
        />
        <x-sidebar-link 
          label='Logs'
          icon="fa-solid fa-clock-rotate-left"
          link="/professor/logs" 
        />
        <x-sidebar-link 
          label='Account'
          icon="fa-solid fa-user-tie"
          link="/professor/account" 
        />
    @elseif (Session::has('parent'))
        <x-sidebar-link 
          label='Dashboard'
          icon="fa-solid fa-chart-line"
          link="/parent/dashboard" 
        />
        <x-sidebar-link 
          label='Account'
          icon="fa-solid fa-user-tie"
          link="/parent/account" 
        />
    @else
      <x-sidebar-link 
          label='Dashboard'
          icon="fa-solid fa-chart-line"
          link="/student/dashboard" 
      />
      <x-sidebar-link 
          label='Schedules'
          icon="fa-solid fa-hourglass-half"
          link="/student/schedules" 
      />
      <x-sidebar-link 
          label='Account'
          icon="fa-solid fa-user-tie"
          link="/student/account" 
      />
    @endif

    <li class="p-1 items-center gap-1 hover:bg-gray-200 hover:rounded flex md:hidden">
        <a href="#" class="me-5 group">
            @if(Session::has('user'))
                <form class="flex items-center gap-1" action="/admin/logout" method="POST">
            @elseif (Session::has('professor'))
                <form class="flex items-center gap-1" action="/professor/logout" method="POST">
            @elseif (Session::has('parent'))
                <form class="flex items-center gap-1" action="/parent/logout" method="POST">
            @else
                <form class="flex items-center gap-1" action="/student/logout" method="POST">
            @endif
                    @csrf
                    <i class="fa-solid fa-right-from-bracket text-gray-600 text-lg"></i>
                    <button type="submit" class="font-semibold text-md text-gray-700 text-xs md:text">Logout</button>
                </form>
        </a>
    </li>

  </ul>