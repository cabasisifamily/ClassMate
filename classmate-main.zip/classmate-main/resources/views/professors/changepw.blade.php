@extends('layouts.reg')
 
@section('title', '- Change Password')

@section('content')
  <div class="flex w-full">

    @include('partials.hero')

    <x-reg-container title="Change Password">

        @if ($errors->any())
            <div class="mt-5">
            @foreach($errors->all() as $err)
                <p class="text-red-500">{{$err}}</p>
            @endforeach
            </div>
        @endif
    
        @if(Session::has('fail'))
            <div class="mt-5">
                <p class="text-red-500">{{Session::get('fail')}}</p>
            </div>
        @endif

        @if(Session::has('success'))
            <div class="mt-5">
                <p class="text-green-500">{{Session::get('success')}}</p>
            </div>
        @endif

      <form action="/professor/change-pw" method="POST" class="w-full flex flex-col gap-3 mt-10 justify-center items-center">
          @csrf

          <x-text-box type="password" label="Current Password" placeHolder="Current Password" name="current_password"/>
          <x-text-box type="password" label="New Password" placeHolder="New Password" name="password"/>
          <x-text-box type="password" label="Confirm Password" placeHolder="Confirm Password" name="password_confirmation"/>

          <x-reg-submit-button 
            label="Change"
          />

      </form>

    </x-reg-container>

    <div class="mb-10"></div>
        

  </div>
@endsection