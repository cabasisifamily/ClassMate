@extends('layouts.main')
 
@section('title', '- Dashboard')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Dashboard</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Dashboard">
                    
            <x-admin-container>

                @if(Session::has('user'))
                    <div class="w-full h-full grid grid-cols-4 gap-4">
                        <div class="w-60 h-32 bg-gray-200 rounded shadow flex items-center flex-col justify-center cursor-pointer">
                            <h1 class="text-xl text-gray-500 font-bold mb-1">Students</h1>
                            <span class="text-xs text-gray-400 mb-2">Total</span>
                            <h2>{{ $data['students'] }}</h2>
                        </div>
                        <div class="w-60 h-32 bg-gray-200 rounded shadow flex items-center flex-col justify-center cursor-pointer">
                            <h1 class="text-xl text-gray-500 font-bold mb-1">Professors</h1>
                            <span class="text-xs text-gray-400 mb-2">Total</span>
                            <h2>{{ $data['professors'] }}</h2>
                        </div>
                    </div>
                @endif

                <div class="w-full h-full grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
                    @foreach ($schedules as $row)
                       <a href="/professor/schedules/{{$row->id}}" target="_blank" class="group">
                            <div class="md:w-60 md:h-32 bg-gray-200 rounded shadow flex items-center flex-col justify-center cursor-pointer group-hover:bg-gray-500">
                                <h1 class="text-md md:text-xl text-gray-500 font-bold mb-1 group-hover:text-white">{{$row->subject}}</h1>
                                <span class="text-xs mb-1">{{$row->section}}</span>
                                <span class="text-xs text-gray-400 mb-1 md:mb-2 group-hover:text-white">{{$row->stime}} - {{$row->etime}} ({{$row->day}})</span>
                                <h2 class="group-hover:text-white text-sm md:text-md">{{ $row->total_minutes }}mins</h2>
                            </div>
                       </a>
                    @endforeach
                </div>
             
            </x-admin-container>
            
        </x-option-container>
    </x-main-container>
@endsection