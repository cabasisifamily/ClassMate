@extends('layouts.main')
 
@section('title', '- Schedules')

@section('location')
  <x-page-label label="Dashboard / Schedules / List" />
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Logs">
            <x-form-container method="GET" action="/professor/logs">

                <div class="flex w-full items-center justify-center">
                    <x-text-box 
                        label="Date" 
                        placeHolder="Date" 
                        name="date" 
                        type="date"
                        value="{{date('Y-m-d')}}"
                    />

                    <x-dropdown label="Schedule" name="schedule_id">
                       @foreach ($schedules as $row)
                        <x-dropdown-option label="{{$row->subject}} - {{$row->section}} ({{$row->stime}} - {{$row->etime}})" value="{{$row->id}}"/>
                       @endforeach
                    </x-dropdown>
                    
                </div>

                <x-reg-submit-button 
                    label="Generate"
                />
            </x-form-container>

            @if(!empty($logs))

                <div class="my-3 flex justify-end items-center gap-2">
                    <x-pdf-link 
                        location="/report/?date={{request('date')}}&schedule_id={{md5(request('schedule_id'))}}"
                        label="Export To PDF"
                        type="pdf"
                    />

                    <x-pdf-link 
                        location="/report/excel/?date={{request('date')}}&schedule_id={{md5(request('schedule_id'))}}"
                        label="Export To Spreadsheet"
                        type="spreadsheet"
                    />

                </div>

                <div class="w-full overflow-y-auto md:overflow-y-visible">
                    <table id="example" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Student Number</th>
                                <th>Name</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($logs as $row)
                                <tr class="hover:bg-gray-200">
                                    <td>{{ $row->student_number }}</td>
                                    <td>{{ $row->name }}</td>
                                    <td>{{ $row->timein }}</td>
                                    <td>{{ $row->timeout }}</td>
                                    <td>{{ $row->status }}</td>
                                </td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Student Number</th>
                                <th>Name</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Status</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            @endif
        </x-option-container>
    </x-main-container>
@endsection