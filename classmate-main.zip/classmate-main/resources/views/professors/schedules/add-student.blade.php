@extends('layouts.main')
 
@section('title', '- Services')

@section('location')
  <x-page-label label="Professor / Schedule / Add Student" />
@endsection

@section('modal')
<div class="w-full h-full bg-gray-300 fixed z-50 bg-opacity-50 hidden flex-col items-center justify-center" id="rf-modal">
    <div class="h-32 w-52 bg-white rounded-lg p-2 shadow-lg">
       <div class="text-center">
           <input type="text" class="w-0 opacity-0" id="rfid">
            <div class="flex flex-col items-center justify-center w-full h-full gap-1">
                <img src="{{ asset('images/rfid.png') }}" alt="" class="w-8 h-auto">
                <h4 class="font-bold tracking-wide text-gray-700">Please tap the RFID</h4>
                <span class="text-xs text-gray-500">Waiting for card...</span>
            </div>
       </div>
    </div>
</div>
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Add Student">

            @if ($errors->any())
                <div class="mt-5">
                @foreach($errors->all() as $err)
                    <p class="text-red-500">{{$err}}</p>
                @endforeach
                </div>
            @endif

            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
            
            <x-form-container method="POST" action="/professor/schedules/add-student">
                @csrf
                <input type="hidden" name="student_id" id="student-id">
                <input type="hidden" name="schedule_id" value="{{$scheduleId}}">
                <div class="flex flex-col md:flex-row w-full items-center justify-center gap-2 md:gap-0">
                    <x-text-box label="First Name" placeHolder="First Name" name="firstname" :readOnly="true" id="firstname" />
                    <x-text-box label="Middle Name"  placeHolder="Middle Name" name="middlename" :readOnly="true" id="middlename"/>
                    <x-text-box label="Last Name" placeHolder="Last Name" name="lastname" :readOnly="true" id="lastname"/>
                </div>


                <div class="flex flex-col md:flex-row w-full items-center justify-center gap-2 md:gap-0">
                    <x-text-box label="birthday" type="date" placeHolder="Birthday" name="birthday" :readOnly="true" id="birthday"/>
                    <x-text-box label="Contact No." placeHolder="Contact No" name="contactNo" :readOnly="true" id="contactNo"/>
                   

                   <div class="flex justify-center items-center w-full h-full">
                        <x-rfid-text 
                            placeHolder="Tap your RFID" 
                            id="rfid-holder"
                            name="rfid"
                            value="{{ old('rfid') }}"
                            buttonId="rf-button"  
                        />
                   </div>
                </div>

                <x-reg-submit-button 
                    label="Submit"
                    id="submit"
                />

            </x-form-container>
            
        </x-option-container>

    </x-main-container>

@section('js')
<script>
    $(document).ready(function() {

        $('#rf-modal').click(function() {
            $(this).addClass("hidden");
            $(this).removeClass("flex");
        })

        $('#rf-button').click(function() {
            $("#rfid-holder").val('');
            $("#rfid").val('');
            $('#rf-modal').removeClass("hidden");
            $('#rf-modal').addClass("flex");
            $("#rfid").focus();
        });

        $("#rfid").keyup(function() {
            let value = $(this).val();3257098195

            if(value.length >= 10) {
                console.log(`value inside:`,value);
                $("#rfid-holder").val('');
                $("#rfid-holder").val($(this).val());
                getStudent($(this).val());
                $('#rf-modal').removeClass("flex");
                $('#rf-modal').addClass("hidden");
                $("#rfid").val('');
            }
        });


        const getStudent = (rfid) => {
            $.get(`/professor/students/${rfid}`, function( data ) {
                console.log($("#firstname"));
                console.log(`data`,data);
                $("#student-id").val(data.id);
                $("#firstname").val(data.firstname);
                $("#middlename").val(data.middlename);
                $("#lastname").val(data.lastname);
                $("#contactNo").val(data.contactNo);
                $("#birthday").val(data.birthday);
            });
        }
    });
</script>
@endsection

@endsection