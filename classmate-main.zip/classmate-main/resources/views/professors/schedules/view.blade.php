@extends('layouts.main')
 
@section('title', '- Schedule')

@section('location')
    <div class="w-full h-12 bg-gray-100 flex items-center">
        <h4 class="ms-4 tracking-wide font-semibold text-gray-500 text-sm">Professor / Schedule / View</h4>
    </div>
@endsection

@section('content')
    <x-main-container>
        <x-option-container :label="$schedule->subject">

            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif
        
            <x-container>
                <x-heading title="Schedule Information">

                    <x-information 
                        label="Day"
                        :value="$schedule->day"
                    />
                
                    <x-information 
                        label="Start Time"
                        :value="$schedule->stime"
                    />

                    <x-information 
                        label="End Time"
                        :value="$schedule->etime"
                    />

                    <x-information 
                        label="Total Minute(s)"
                        :value="$schedule->total_minutes"
                    />

                    <x-information 
                        label="Active"
                        :value="$schedule->status"
                    />

                </x-heading>


                <x-heading title="Students" :button="true" buttonLabel="Add Student" location="/professor/schedules/{{$schedule->id}}/add-student">
                    @foreach ($students as $row)
                        <x-information 
                            label="{{$row->id}}"
                            :value="$row->lastname . ', ' . $row->firstname . ' ' . $row->middlename"
                        />
                    @endforeach
                </x-heading>
                
                    
            </x-container>
   
            
        </x-option-container>
    </x-main-container>
@endsection