@extends('professors.timekeeping.layout')
@section('title', "- Timekeeping")

@section('content')

    <div class="w-full bg-gray-500 text-white text-lg font-bold py-2 px-3 flex justify-between">
        <h1 class="">{{$schedule->subject}}</h1>
        <h1>{{$schedule->stime}} to {{$schedule->etime}}</h1>
        <h1>{{$schedule->total_minutes}}mins</h1>
    </div>

    <div class="py-1 px-2" id="notification">
        <h1 class="text-white font-bold" id="notification-message"></h1>
    </div>

    <div class="text-center">
        <input type="text" class="w-0 opacity-0" id="rfid">
        <div class="flex flex-col items-center justify-center w-full h-full gap-1">
            <img src="{{ asset('images/rfid.png') }}" alt="" class="w-8 h-auto">
            <h4 class="font-bold tracking-wide text-gray-700">Tap your RFID to timein or timeout</h4>
        </div>
    </div>

    <div class="flex items-center justify-center mt-10">
        <h2 class="text-4xl font-bold" id="time-display">Loading...</h2>
    </div>

    <div class="w-full mt-10">
        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr class="text-center">
                    <th scope="col" class="px-6 py-3">Picture</th>
                    <th scope="col" class="px-6 py-3">Name</th>
                    <th scope="col" class="px-6 py-3">Time In</th>
                    <th scope="col" class="px-6 py-3">Time Out</th>
                    <th scope="col" class="px-6 py-3"></th>
                </tr>
            </thead>
            <tbody id="table-body">
                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 text-center"></tr>
            </tbody>
        </table>
    </div>

@endsection



@section('js')
    <script>
        $(document).ready(function() {
            $("#notification").fadeOut();
            function updateTime() {
                $("#rfid").focus();
                var currentTime = new Date($.now());
                var hours = currentTime.getHours();
                var minutes = currentTime.getMinutes();
                var seconds = currentTime.getSeconds();
                var ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12;
                minutes = minutes < 10 ? '0' + minutes : minutes;
                seconds = seconds < 10 ? '0' + seconds : seconds;
                var formattedTime = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
                $('#time-display').text('Current Time: ' + formattedTime);
            }

            $("#rfid").keyup(function() {
                let value = $(this).val();
                if(value.length >= 10) {
                    console.log(`value inside:`,value);
                    timeinTimeout(value);
                    getActivity('{{$schedule->id}}');
                    $("#rfid").val('');
                }
            });

            $("#table-body").on("click", ".btn-absent", function() {
                let studentId = $(this).data("sid");
                const postData = {
                    student_id: studentId,
                    schedule_id: {{$schedule->id}},
                    _token: '{{ csrf_token() }}',
                };
                
                if(confirm("Are you sure you want to mark this student as Absent?")) {
                    $.post(`/professor/schedules/mark-absent`, postData, function(data) {
                        console.log(`markAbsent result:`,data);
                        if(data.success) {
                            getActivity('{{$schedule->id}}');
                            notif(data.message);
                        } else {
                            getActivity('{{$schedule->id}}');
                            notif(data.message,false);
                        }
                    });
                }

            });

            const timeinTimeout = (rfid) => {
                const postData = {
                    rfid: rfid,
                    schedule_id: {{$schedule->id}},
                    _token: '{{ csrf_token() }}',
                };
                $.post(`/professor/schedules/timekeeping`, postData, function(data) {
                    console.log(`timeinTimeout result:`,data);
                    if(data.success) {
                        notif(data.message);
                    } else {
                        notif(data.message,false);
                    }
                });
            };

            const getActivity = (scheduleId) => {
                $.get(`/professor/schedules/get-activity/${scheduleId}`, function( res ) {
                    console.log(`data`,res);
                    if(res.success) {
                        $("#table-body").empty();
                        let values = "";
                        res.data.map((row,key) => {
                            let newRow = $("<tr class='bg-white border-b dark:bg-gray-800 dark:border-gray-700 text-center'>");
                            let picture = "{{ asset('storage') }}" + "/" + row.picture
                            newRow.append(`<td class='px-6 py-4 flex justify-center items-center'><img src='${picture}' class='rounded-full object-cover w-16 h-16 shadow' /></td>`);
                            newRow.append(`<td class='px-6 py-4'>${row.name.toUpperCase()}</td>`);
                            newRow.append(`<td class='px-6 py-4 text-green-400 font-bold'>${row.timein ?? ''}</td>`);
                            newRow.append(`<td class='px-6 py-4 text-red-400 font-bold'>${row.timeout ?? ''}</td>`);
                            newRow.append(`
                                <td class='text-gray-700 font-bold ${row.status === 'Absent' ? 'text-red-500':''}'>
                                    ${row.status ?? `<button type="button" data-sid="${row.student_id}" class="btn-absent text-white bg-red-400 py-1 px-2 rounded hover:bg-red-500">Mark as Absent</button>`}
                                </td>`);
                            newRow.append("</tr>");
                            $("#table-body").append(newRow);
                        });
                    } else {
                        console.log(`no data`);
                    }
                    
                });
            }

            const notif = (message,success=true) => {
                $("#notification").fadeIn();
                if(success) {
                    $("#notification").addClass("bg-green-600");
                } else {
                    $("#notification").addClass("bg-red-600");
                }
                $("#notification-message").text(message);
                setTimeout(function() {
                    $("#notification").fadeOut();
                }, 4000);
            }
            getActivity('{{$schedule->id}}');
            setInterval(updateTime, 1000);
        });
    </script>
@endsection
