<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/x-icon" href="{{ asset('images/logo-icon.png') }}">
  <title>ClassMate @yield('title')</title>
  <link rel="stylesheet" href="{{ asset('fontawesome-free-6.4.2/css/all.min.css') }}">
  @vite('resources/css/app.css')
  <!-- <link rel="stylesheet" href="{{ asset('build/assets/app-8e25826b.css') }}"> -->
</head>
<body>
      @include('layouts.header')

      <div class="gap-5 mt-10 mx-10">
            @yield('content')
      </div>

      <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
      <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.13.6/js/dataTables.tailwindcss.min.js"></script>
      <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
      <script src="https://cdn.tailwindcss.com"></script>

      @yield('js')
      {{-- @include('layouts.footer') --}}
      
</body>
</html>