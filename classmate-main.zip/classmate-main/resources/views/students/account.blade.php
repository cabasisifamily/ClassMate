@extends('layouts.main')
 
@section('title', '- Students')

@section('location')
  <x-page-label label="Dashboard / Students" />
@endsection

@section('content')
    <x-main-container>

        <x-option-container label="Manage Students">
            
            <x-admin-container>

                <x-option-item 
                    icon="fa-solid fa-user-lock"
                    label="Change Password"
                    description="change your password"
                    link="/student/changepw"
                />
                
            </x-admin-container>
            
        </x-option-container>

    </x-main-container>
@endsection