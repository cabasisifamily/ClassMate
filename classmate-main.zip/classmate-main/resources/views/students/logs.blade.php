@extends('layouts.main')
 
@section('title', '- Schedules')

@section('location')
  <x-page-label label="Dashboard / Schedules / Logs" />
@endsection

@section('content')
    <x-main-container>
        <x-option-container label="Schedule logs">

            @if(Session::has('success'))
                <div class="mt-5">
                    <p class="text-green-500">{!! Session::get('success') !!}</p>
                </div>
            @endif

            @if(Session::has('fail'))
                <div class="mt-5">
                    <p class="text-red-500">{!! Session::get('fail') !!}</p>
                </div>
            @endif
            
            <div class="w-full">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($logs as $row)
                            <tr class="hover:bg-gray-200 {{$row->description == 'Absent' ? 'text-red-500':''}}">
                                <td>{{ $row->date }}</td>
                                <td>{{ $row->timein }}</td>
                                <td>{{ $row->timeout }}</td>
                                <td>{{ $row->description }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Description</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
        </x-option-container>

    </x-main-container>
@endsection