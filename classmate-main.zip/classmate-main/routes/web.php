<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\ProfessorController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ParentController;
use App\Http\Controllers\ParentStudentController;
use App\Http\Controllers\NotificationController;

Route::middleware(['no.auth'])->group(function () {
    Route::get('/', [UserController::class,'loginUI'])->name('login');
    Route::post('/login', [UserController::class,'login']);
});


Route::get('/student/login', [StudentController::class,'login'])->name('student.login');
Route::post('/student/login', [StudentController::class,'tryLogin']);

Route::get('/professor/login', [ProfessorController::class,'login'])->name('professor.login');
Route::post('/professor/login', [ProfessorController::class,'tryLogin']);

Route::get('/admin/login', [AdminController::class,'login'])->name('admin.login');
Route::post('/admin/login', [UserController::class,'login']);


Route::group(['prefix' => 'student','middleware' => 'student.auth'], function () {
    Route::get('dashboard', [StudentController::class,'dashboard']);
    Route::get('account', [StudentController::class,'account']);
    Route::post('logout', [StudentController::class,'logout']);
    Route::get('changepw', [StudentController::class,'changepw'])->name('student.changepw');
    Route::post('change-pw', [StudentController::class,'storeChange']);
    Route::get('schedules', [StudentController::class,'schedules'])->name('student.schedules');
    Route::get('/schedules/{id}/logs', [StudentController::class,'logs'])->name('student.logs');
});


Route::group(['prefix' => 'professor','middleware' => 'professor.auth'], function () {
    
    Route::post('logout', [ProfessorController::class,'logout']);
    Route::get('dashboard', [ProfessorController::class,'dashboard'])->name('professor.dashboard');
    Route::get('change-pw', [ProfessorController::class,'change'])->name('professor.changepw');
    Route::post('change-pw', [ProfessorController::class,'storeChange']);
    Route::get('schedules', [ProfessorController::class,'schedules'])->name('professor.schedules');
    Route::get('logs', [ProfessorController::class,'logs'])->name('professor.logs');
    Route::get('account', [ProfessorController::class,'accounts'])->name('professor.accounts');
    Route::get('/schedules/{id}/view', [ProfessorController::class,'view'])->name('professor.schedule.view');
    Route::get('/schedules/{id}/add-student', [ProfessorController::class,'addStudent'])->name('professor.schedule.add-student');
    Route::get('/students/{rfid}', [ProfessorController::class,'getStudent'])->name('professor.students.get');
    Route::post('/schedules/add-student', [ProfessorController::class,'storeStudent']);
    Route::post('/schedules/timekeeping', [ProfessorController::class,'storeTime']);
    Route::get('/schedules/{id}', [ProfessorController::class,'timekeeping']);
    Route::get('/schedules/get-activity/{scheduleId}', [ProfessorController::class,'getActivity']);
    Route::post('/schedules/mark-absent', [ProfessorController::class,'markAbsent']);

});

Route::group(['prefix' => 'report','middleware' => 'professor.auth'], function () {
    Route::get('/', [ReportController::class,'index'])->name('report.index');
    Route::get('/excel', [ReportController::class,'excel'])->name('report.excel');
});

Route::group(['prefix' => 'parent','middleware' => 'parent.auth'], function () {
    Route::get('dashboard', [ParentController::class,'dashboard'])->name('parent.dashboard');
    Route::get('change-pw', [ParentController::class,'changepw'])->name('parent.changepw');
    Route::get('students', [ParentController::class,'students'])->name('parent.students');
    Route::get('account', [ParentController::class,'account'])->name('parent.account');
    Route::get('students/{id}/view', [ParentController::class,'show'])->name('parent.show');
    Route::get('notifications', [NotificationController::class,'index'])->name('parent.notifications');
    Route::get('notifications/{id}', [NotificationController::class,'show'])->name('parent.notifications.show');
    Route::post('change-pw', [ParentController::class,'storeChange']);
    Route::post('logout', [ParentController::class,'logout']);
});

Route::group(['prefix' => 'admin','middleware' => 'dashboard.auth'], function () {
    
    Route::post('logout', [UserController::class,'logout']);
    Route::get('dashboard', [AdminController::class,'dashboard'])->name('admin.dashboard');
    Route::get('account', [AdminController::class,'account'])->name('admin.account');
    Route::get('changepw', [AdminController::class,'changepw'])->name('admin.changepw');
    Route::post('change-pw', [AdminController::class,'storeChange']);
    
    Route::get('students', [AdminController::class,'students'])->name('admin.students');
    Route::get('students/create', [StudentController::class,'create'])->name('student.create');
    Route::post('students/create', [StudentController::class,'store']);
    Route::get('students/list', [StudentController::class,'index'])->name('admin.students.list');
    Route::get('/students/{id}/view', [StudentController::class,'show'])->name('admin.students.view');
    Route::get('/students/{id}/edit', [StudentController::class,'edit'])->name('admin.students.edit');
    Route::put('/students/{id}/edit', [StudentController::class,'update']);
    
    Route::get('professors', [AdminController::class,'professors'])->name('admin.professors');
    Route::get('professors/create', [ProfessorController::class,'create'])->name('admin.professors.create');
    Route::post('professors/create', [ProfessorController::class,'store']);
    Route::get('professors/list', [ProfessorController::class,'index'])->name('admin.professors.list');
    Route::get('professors/{id}/view', [ProfessorController::class,'show'])->name('admin.professors.view');
    Route::get('professors/{id}/edit', [ProfessorController::class,'edit'])->name('admin.professors.edit');
    Route::put('professors/{id}/edit', [ProfessorController::class,'update']);

    Route::get('users', [AdminController::class,'users'])->name('admin.users');
    Route::get('users/create', [UserController::class,'create'])->name('admin.users.create');
    Route::post('users/create', [UserController::class,'store']);
    Route::get('users/list', [UserController::class,'index'])->name('admin.users.list');
    Route::get('users/{id}/edit', [UserController::class,'edit'])->name('admin.users.edit');
    Route::put('users/{id}/edit', [UserController::class,'update'])->name('admin.users.update');

    Route::get('utilities', [AdminController::class,'utilities'])->name('admin.utilities');

    Route::get('subjects/create', [SubjectController::class,'create'])->name('admin.subjects.create');
    Route::post('subjects/create', [SubjectController::class,'store']);
    Route::get('subjects/list', [SubjectController::class,'index'])->name('admin.subjects.list');
    Route::get('subjects/{id}/edit', [SubjectController::class,'edit'])->name('admin.subjects.edit');
    Route::put('subjects/{id}/edit', [SubjectController::class,'update']);

    Route::get('schedules/create', [ScheduleController::class,'create'])->name('admin.schedule.create');
    Route::post('schedules/create', [ScheduleController::class,'store']);
    Route::get('schedules/list', [ScheduleController::class,'index'])->name('admin.schedules.list');
    Route::get('schedules/{id}/edit', [ScheduleController::class,'edit'])->name('admin.schedules.edit');
    Route::put('schedules/{id}/edit', [ScheduleController::class,'update']);

    Route::get('courses/create', [CourseController::class,'create'])->name('admin.courses.create');
    Route::post('courses/create', [CourseController::class,'store']);
    Route::get('courses/list', [CourseController::class,'index'])->name('admin.courses.list');
    Route::get('courses/{id}/edit', [CourseController::class,'edit'])->name('admin.courses.edit');
    Route::put('courses/{id}/edit', [CourseController::class,'update']);

    Route::get('sections/create', [SectionController::class,'create'])->name('admin.sections.create');
    Route::post('sections/create', [SectionController::class,'store']);
    Route::get('sections/list', [SectionController::class,'index'])->name('admin.sections.list');
    Route::get('sections/{id}/edit', [SectionController::class,'edit'])->name('admin.sections.edit');
    Route::put('sections/{id}/edit', [SectionController::class,'update']);

    Route::get('parents', [AdminController::class,'parents'])->name('admin.parents');
    Route::get('parents/create', [ParentController::class,'create'])->name('admin.parents.create');
    Route::post('parents/create', [ParentController::class,'store']);
    Route::get('parents/list', [ParentController::class,'index'])->name('admin.parents.list');
    Route::get('parents/{id}/edit', [ParentController::class,'edit'])->name('admin.parents.edit');
    Route::put('parents/{id}/edit', [ParentController::class,'update']);
    Route::get('parents/{id}/view', [ParentController::class,'view'])->name('admin.parents.view');

    Route::post('students/parents/add', [ParentStudentController::class,'store']);
    Route::post('students/parents/delete', [ParentStudentController::class,'destroy']);
});
